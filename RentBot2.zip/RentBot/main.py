# main.py
import asyncio
import logging
import os
from dotenv import load_dotenv
from aiogram import F # Убедимся, что F импортирован

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand

from app.handlers import admin_handlers, client_handlers
from app.models.database import create_db
from app.scheduler import check_expired_rentals
from app.middlewares.maintenance import MaintenanceMiddleware # НОВЫЙ ИМПОРТ
from app.settings import get_admin_ids # НОВЫЙ ИМПОРТ

# ПЕРЕОПРЕДЕЛЯЕМ ФИЛЬТР ДЛЯ АДМИНОВ, ЧТОБЫ ОН ИСПОЛЬЗОВАЛ СПИСОК
admin_handlers.router.message.filter(F.from_user.id.in_(get_admin_ids()))
admin_handlers.router.callback_query.filter(F.from_user.id.in_(get_admin_ids()))

async def set_bot_commands(bot: Bot):
    commands = [
        BotCommand(command="start", description="Запуск / Перезапуск бота"),
        BotCommand(command="admin", description="Панель администратора")
    ]
    await bot.set_my_commands(commands)

async def main() -> None:
    if not BOT_TOKEN:
        logging.critical("ОШИБКА: Не удалось загрузить BOT_TOKEN.")
        return

    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(name)s - %(message)s')
    
    logging.info("Запуск фоновых задач...")
    asyncio.create_task(check_expired_rentals())
    
    logging.info("Инициализация базы данных...")
    create_db()
    
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    logging.info("Регистрация обработчиков...")
    
    # ИЗМЕНЕНО: Регистрируем middleware для клиентского роутера
    client_handlers.router.message.middleware(MaintenanceMiddleware())
    client_handlers.router.callback_query.middleware(MaintenanceMiddleware())
    
    dp.include_router(admin_handlers.router)
    dp.include_router(client_handlers.router)
    
    await set_bot_commands(bot)

    logging.info("Запуск бота...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())