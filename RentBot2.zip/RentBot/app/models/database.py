# app/models/database.py
from sqlalchemy import (create_engine, Column, Integer, String, BigInteger, 
                        ForeignKey, DateTime, func, Boolean, Text)
from sqlalchemy.orm import sessionmaker, declarative_base, relationship
import datetime

DATABASE_URL = "sqlite:///./rentbot.db"
Base = declarative_base()

class Blacklist(Base):
    __tablename__ = 'blacklist'
    user_id = Column(BigInteger, primary_key=True)
    user_name = Column(String)
    reason = Column(String, default="Нарушение правил")
    blocked_at = Column(DateTime, default=datetime.datetime.now)
    appeal_attempts_left = Column(Integer, default=2)
    last_appeal_at = Column(DateTime, nullable=True)

class SupportTicket(Base):
    __tablename__ = 'support_tickets'
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, index=True)
    user_name = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.now)
    is_closed = Column(Boolean, default=False)
    is_appeal = Column(Boolean, default=False)
    closed_at = Column(DateTime, nullable=True) 
    messages = relationship("TicketMessage", back_populates="ticket", cascade="all, delete-orphan")

class TicketMessage(Base):
    __tablename__ = 'ticket_messages'
    id = Column(Integer, primary_key=True)
    ticket_id = Column(Integer, ForeignKey('support_tickets.id'))
    sender_type = Column(String) 
    message_text = Column(Text, nullable=True)
    photo_file_id = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.now)
    ticket = relationship("SupportTicket", back_populates="messages")

class Account(Base):
    __tablename__ = 'accounts'
    id = Column(Integer, primary_key=True)
    acc_id = Column(String, unique=True, index=True, nullable=False)
    adobe_email = Column(String)
    adobe_password = Column(String)
    imap_server = Column(String)
    imap_email = Column(String)
    imap_password = Column(String)
    usage_limit = Column(Integer, default=1) 
    rentals = relationship("Rental", back_populates="account", cascade="all, delete-orphan")
    pool_links = relationship("AccountPoolLink", back_populates="account", cascade="all, delete-orphan")

class Pool(Base):
    __tablename__ = 'pools'
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    accounts = relationship("AccountPoolLink", back_populates="pool", cascade="all, delete-orphan")
    keys = relationship("ActivationKey", back_populates="pool", cascade="all, delete-orphan")
    waiting_list = relationship("WaitingList", back_populates="pool", cascade="all, delete-orphan")

class AccountPoolLink(Base):
    __tablename__ = 'account_pool_links'
    id = Column(Integer, primary_key=True)
    account_id = Column(Integer, ForeignKey('accounts.id', ondelete="CASCADE"))
    pool_id = Column(Integer, ForeignKey('pools.id', ondelete="CASCADE"))
    pool = relationship("Pool", back_populates="accounts")
    account = relationship("Account", back_populates="pool_links")

class Rental(Base):
    __tablename__ = 'rentals'
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, index=True)
    end_time = Column(DateTime)
    account_id = Column(Integer, ForeignKey('accounts.id'))
    account = relationship("Account", back_populates="rentals")
    key_id = Column(Integer, ForeignKey('activation_keys.id', ondelete="SET NULL"), unique=True, nullable=True)
    key = relationship("ActivationKey", back_populates="rental")

class ActivationKey(Base):
    __tablename__ = 'activation_keys'
    id = Column(Integer, primary_key=True)
    key = Column(String, unique=True, nullable=False)
    duration_days = Column(Integer, nullable=False)
    # ИЗМЕНЕНО: Добавлено правило ondelete для целостности данных
    pool_id = Column(Integer, ForeignKey('pools.id', ondelete="CASCADE"))
    pool = relationship("Pool", back_populates="keys")
    is_activated = Column(Boolean, default=False)
    activated_by_user_id = Column(BigInteger, nullable=True)
    activated_at = Column(DateTime, nullable=True)
    activated_by_user_name = Column(String, nullable=True)
    rental = relationship("Rental", back_populates="key", cascade="all, delete-orphan", uselist=False)

# ИЗМЕНЕНА ТАБЛИЦА: Очередь ожидания
class WaitingList(Base):
    __tablename__ = 'waiting_list'
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, index=True, nullable=False)
    user_name = Column(String)
    # ИЗМЕНЕНО: Добавлено правило ondelete
    pool_id = Column(Integer, ForeignKey('pools.id', ondelete="CASCADE"), nullable=False)
    # ИЗМЕНЕНО: Добавлено правило ondelete и уникальность
    key_id = Column(Integer, ForeignKey('activation_keys.id', ondelete="CASCADE"), unique=True, nullable=False)
    added_at = Column(DateTime, default=datetime.datetime.now)

    pool = relationship("Pool", back_populates="waiting_list")
    key = relationship("ActivationKey") # Добавлена связь для удобства

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def create_db():
    Base.metadata.create_all(bind=engine)