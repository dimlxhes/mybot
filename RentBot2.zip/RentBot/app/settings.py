# app/settings.py
import json
import os
import logging

SETTINGS_FILE = 'settings.json'
# Получаем ID главного админа из переменных окружения
MAIN_ADMIN_ID = int(os.getenv("ADMIN_ID", 0))

DEFAULT_SETTINGS = {
    "maintenance_mode": False,
    "maintenance_reason": "⚙️ Ведутся технические работы. Попробуйте позже.",
    "notify_on_code_request": True,
    "notify_on_activation": True,
    "notify_on_new_ticket": True,
    "admin_ids": [MAIN_ADMIN_ID] if MAIN_ADMIN_ID != 0 else []
}

def load_settings():
    if not os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(DEFAULT_SETTINGS, f, indent=4, ensure_ascii=False)
        return DEFAULT_SETTINGS
    try:
        with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
            settings = json.load(f)
            # Убедимся, что все ключи из настроек по умолчанию присутствуют
            for key, value in DEFAULT_SETTINGS.items():
                settings.setdefault(key, value)
            # Гарантируем наличие главного админа в списке
            if MAIN_ADMIN_ID != 0 and MAIN_ADMIN_ID not in settings["admin_ids"]:
                settings["admin_ids"].append(MAIN_ADMIN_ID)
            return settings
    except (json.JSONDecodeError, IOError) as e:
        logging.error(f"Could not load settings file: {e}. Loading defaults.")
        return DEFAULT_SETTINGS

def save_settings(settings):
    try:
        # Гарантируем наличие главного админа при сохранении
        if MAIN_ADMIN_ID != 0 and MAIN_ADMIN_ID not in settings["admin_ids"]:
            settings["admin_ids"].append(MAIN_ADMIN_ID)
        
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=4, ensure_ascii=False)
    except IOError as e:
        logging.error(f"Error saving settings: {e}")

# Загружаем настройки при старте модуля
settings_manager = load_settings()

# ИСПРАВЛЕНИЕ: Добавлена недостающая функция
def get_admin_ids():
    """Возвращает список ID всех администраторов."""
    return settings_manager.get("admin_ids", [MAIN_ADMIN_ID] if MAIN_ADMIN_ID != 0 else [])