# app/utils.py
import imaplib, email, re, json, datetime, os
from email.header import decode_header
from aiogram import Bot
from aiogram.types import Message, CallbackQuery

from app.models.database import SessionLocal, Blacklist, Account, Pool, SupportTicket
from app.keyboards.inline import appeal_keyboard

LOG_FILE = "activations.log.json"
ACCOUNTS_FILE = "accounts.data.json"
POOLS_FILE = "pools.data.json"
BLACKLIST_FILE = "blacklist.data.json"
TICKETS_FILE = "tickets.data.json"


async def check_and_handle_blocked_user(event: Message | CallbackQuery) -> bool:
    user_id = event.from_user.id
    db = SessionLocal()
    blocked_user = db.query(Blacklist).filter(Blacklist.user_id == user_id).first()
    db.close()

    if blocked_user:
        text = (
            f"<b>Вы были заблокированы в боте.</b>\n\n"
            f"Причина: {blocked_user.reason}\n"
            f"Осталось попыток апелляции: {blocked_user.appeal_attempts_left}"
        )
        if isinstance(event, Message):
            await event.answer(text, reply_markup=appeal_keyboard())
        elif isinstance(event, CallbackQuery):
            await event.message.answer(text, reply_markup=appeal_keyboard())
            await event.answer("Вы заблокированы.", show_alert=True)
        return True
    
    return False

def log_activation_to_json(data: dict):
    try:
        for key, value in data.items():
            if isinstance(value, datetime.datetime):
                data[key] = value.isoformat()
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r', encoding='utf-8') as f:
                logs = json.load(f)
        else:
            logs = []
        logs.append(data)
        with open(LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump(logs, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"Error while logging to JSON: {e}")

def get_adobe_code(server: str, user: str, password: str, check_only: bool = False) -> str:
    try:
        imap = imaplib.IMAP4_SSL(server, timeout=10)
        imap.login(user, password)
        
        # ИЗМЕНЕНО: Добавлена логика для check_only
        if check_only:
            imap.logout()
            return "OK"

        imap.select("INBOX")
        status, messages = imap.search(None, '(FROM "adobe.com" UNSEEN)')
        if not messages[0].split(): status, messages = imap.search(None, '(FROM "adobe.com")')
        if not messages[0].split(): return "Писем от Adobe не найдено."
        latest_id = messages[0].split()[-1]
        status, msg_data = imap.fetch(latest_id, "(RFC822)")
        msg = email.message_from_bytes(msg_data[0][1])
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if "text" in part.get_content_type():
                    try: body = part.get_payload(decode=True).decode(); break
                    except: continue
        else: body = msg.get_payload(decode=True).decode()
        match = re.search(r'>(\d{6})<', body) or re.search(r'\b(\d{6})\b', body)
        if match:
            code = match.group(1) if match.group(1) else match.group(0)
            imap.store(latest_id, '+FLAGS', '(\\Seen)'); imap.logout()
            return f"✅ Ваш код: {code}"
        imap.logout(); return "Не удалось найти 6-значный код в письме."
    except Exception as e: return f"❌ Ошибка подключения: {e}"

def export_accounts_to_json():
    db = SessionLocal()
    try:
        all_accounts = db.query(Account).order_by(Account.acc_id).all()
        accounts_list = [{"id": acc.id, "acc_id": acc.acc_id, "adobe_email": acc.adobe_email, "adobe_password": acc.adobe_password, "imap_server": acc.imap_server, "imap_email": acc.imap_email, "imap_password": acc.imap_password} for acc in all_accounts]
        with open(ACCOUNTS_FILE, 'w', encoding='utf-8') as f:
            json.dump(accounts_list, f, ensure_ascii=False, indent=4)
    finally:
        db.close()

def export_pools_to_json():
    from sqlalchemy.orm import joinedload
    from app.models.database import Pool, AccountPoolLink
    db = SessionLocal()
    try:
        all_pools = db.query(Pool).options(joinedload(Pool.accounts).joinedload(AccountPoolLink.account)).order_by(Pool.name).all()
        pools_list = [{"id": p.id, "name": p.name, "accounts": [link.account.acc_id for link in p.accounts if link.account]} for p in all_pools]
        with open(POOLS_FILE, 'w', encoding='utf-8') as f:
            json.dump(pools_list, f, ensure_ascii=False, indent=4)
    finally:
        db.close()

def export_blacklist_to_json():
    db = SessionLocal()
    try:
        users = db.query(Blacklist).all()
        blacklist_list = [{"user_id": user.user_id, "user_name": user.user_name, "reason": user.reason, "blocked_at": user.blocked_at.isoformat(), "appeal_attempts_left": user.appeal_attempts_left, "last_appeal_at": user.last_appeal_at.isoformat() if user.last_appeal_at else None} for user in users]
        with open(BLACKLIST_FILE, 'w', encoding='utf-8') as f:
            json.dump(blacklist_list, f, ensure_ascii=False, indent=4)
    finally:
        db.close()

def export_tickets_to_json():
    from sqlalchemy.orm import joinedload
    db = SessionLocal()
    try:
        tickets = db.query(SupportTicket).options(joinedload(SupportTicket.messages)).all()
        tickets_list = [{"ticket_id": ticket.id, "user_id": ticket.user_id, "user_name": ticket.user_name, "is_closed": ticket.is_closed, "is_appeal": ticket.is_appeal, "created_at": ticket.created_at.isoformat(), "closed_at": ticket.closed_at.isoformat() if ticket.closed_at else None, "messages": [{"sender": msg.sender_type, "text": msg.message_text, "photo_id": msg.photo_file_id, "timestamp": msg.created_at.isoformat()} for msg in ticket.messages]} for ticket in tickets]
        with open(TICKETS_FILE, 'w', encoding='utf-8') as f:
            json.dump(tickets_list, f, ensure_ascii=False, indent=4)
    finally:
        db.close()