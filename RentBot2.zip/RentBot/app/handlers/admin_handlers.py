# app/handlers/admin_handlers.py
import os, uuid, logging, io, datetime
from aiogram import Router, F, types, exceptions, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BufferedInputFile, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from sqlalchemy.orm import joinedload
from sqlalchemy import desc, func, or_
from math import ceil

from app.keyboards.inline import *
from app.keyboards.callbacks import AdminCallback
from app.models.database import SessionLocal, Account, Pool, AccountPoolLink, ActivationKey, Rental, SupportTicket, TicketMessage, Blacklist, WaitingList
from app.utils import get_adobe_code, export_accounts_to_json, export_pools_to_json, export_blacklist_to_json, export_tickets_to_json
from app.settings import settings_manager, save_settings, get_admin_ids

router = Router()
PAGE_SIZE_KEYS = 10
PAGE_SIZE = 5

# --- Состояния FSM ---
class AddAccount(StatesGroup):
    acc_id, adobe_email, adobe_password, imap_server, imap_email, imap_password = State(), State(), State(), State(), State(), State()
class AddPool(StatesGroup): name = State()
class AddAccountToPool(StatesGroup): acc_id = State()
class GenerateKeys(StatesGroup): duration, amount, pool_id = State(), State(), State()
class BulkAddAccounts(StatesGroup): awaiting_message = State()
class BulkDeleteKeys(StatesGroup): selecting = State()
class SupportReplyState(StatesGroup):
    awaiting_reply_message = State()
class BlockUserState(StatesGroup):
    awaiting_reason = State()
class SetLimitState(StatesGroup):
    awaiting_limit = State()
class ReplaceRental(StatesGroup):
    selecting_account = State()
    confirming_replacement = State()
class EditAccount(StatesGroup):
    awaiting_value = State()
class SearchKeys(StatesGroup):
    awaiting_query = State()
class BulkDeleteAccounts(StatesGroup):
    selecting = State()
class MaintenanceState(StatesGroup):
    awaiting_reason = State()
class BulkDeleteTickets(StatesGroup):
    selecting = State()
class AdminManagement(StatesGroup):
    awaiting_add = State()
# НОВЫЕ СОСТОЯНИЯ
class ReplaceAccountData(StatesGroup):
    awaiting_data = State()
class DirectMessage(StatesGroup):
    awaiting_message = State()

# --- Обработчики ---
@router.errors()
async def error_handler(event: types.ErrorEvent):
    if isinstance(event.exception, exceptions.TelegramBadRequest) and any(msg in event.exception.message for msg in ["message is not modified", "message can't be edited", "message to edit not found"]):
        logging.warning(f"Handled TelegramBadRequest: {event.exception.message}")
        if event.update.callback_query:
            await event.update.callback_query.answer()
        return True
    logging.exception(f"Unhandled exception: {event.exception}\nUpdate: {event.update}")
    if event.update.callback_query:
        try:
            await event.update.callback_query.message.answer("❗️ Произошла непредвиденная ошибка. Проверьте логи.")
        except Exception as e:
            logging.error(f"Could not send error message to user: {e}")

@router.message(Command("admin"))
async def admin_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Панель управления:", reply_markup=admin_main_menu())

@router.callback_query(AdminCallback.filter(F.action == "main_menu"))
async def back_to_main_menu(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("Панель управления:", reply_markup=admin_main_menu())

# --- Управление арендаторами и замена ---

@router.callback_query(AdminCallback.filter(F.action == "view_renters"))
async def view_renters_handler(callback_or_message: types.CallbackQuery | types.Message, callback_data: AdminCallback, state: FSMContext):
    await state.clear()
    page = callback_data.page
    pool_id_filter = callback_data.item_id if callback_data.item_id != 0 else None
    
    db = SessionLocal()
    query = db.query(Rental).options(
        joinedload(Rental.account),
        joinedload(Rental.key)
    ).filter(Rental.end_time > datetime.datetime.now())

    if pool_id_filter:
        query = query.join(ActivationKey).filter(ActivationKey.pool_id == pool_id_filter)

    total_items = query.count()
    total_pages = ceil(total_items / PAGE_SIZE) if total_items > 0 else 1
    rentals = query.order_by(desc(Rental.end_time)).limit(PAGE_SIZE).offset(page * PAGE_SIZE).all()
    
    pool_name = db.query(Pool.name).filter(Pool.id == pool_id_filter).scalar() if pool_id_filter else None
    db.close()
    
    title = "👥 Активные арендаторы"
    if pool_name:
        title += f" (Фильтр: {pool_name})"

    message = callback_or_message.message if isinstance(callback_or_message, types.CallbackQuery) else callback_or_message
    
    try:
        await message.edit_text(title, reply_markup=renters_menu(rentals, page, total_pages, pool_id_filter))
    except exceptions.TelegramBadRequest:
        # Если сообщение не изменилось, просто игнорируем
        if isinstance(callback_or_message, types.CallbackQuery):
            await callback_or_message.answer()
        return

    if isinstance(callback_or_message, types.CallbackQuery):
        await callback_or_message.answer()


@router.callback_query(AdminCallback.filter(F.action == "select_pool_for_filter"))
async def select_pool_to_filter_handler(callback: CallbackQuery):
    db = SessionLocal()
    pools = db.query(Pool).order_by(Pool.name).all()
    db.close()
    await callback.message.edit_text("Выберите пул для фильтрации арендаторов:", reply_markup=select_pool_for_filter_menu(pools))
    await callback.answer()

# НОВЫЙ ОБРАБОТЧИК: Начать диалог с конкретным клиентом
@router.callback_query(AdminCallback.filter(F.action == "dm_renter_single"))
async def start_dm_single_renter(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    user_id = callback_data.item_id
    await state.set_state(DirectMessage.awaiting_message)
    await state.update_data(user_id=user_id)
    await callback.message.edit_text(
        f"✍️ Введите сообщение для пользователя с ID <code>{user_id}</code>:",
        reply_markup=back_button(1, "view_renters")
    )

# НОВЫЙ ОБРАБОТЧИК: Отправка сообщения конкретному клиенту
@router.message(DirectMessage.awaiting_message)
async def process_dm_single_renter(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    user_id = data.get("user_id")
    await state.clear()
        
    try:
        await bot.send_message(user_id, f"Сообщение от администратора:\n\n{message.text}")
        await message.answer(f"✅ Сообщение пользователю {user_id} отправлено.")
    except Exception as e:
        await message.answer(f"❌ Не удалось отправить сообщение: {e}")
    
    await view_renters_handler(message, AdminCallback(page=0, action="view_renters"), state)

@router.callback_query(AdminCallback.filter(F.action == "start_replacement"))
async def start_replacement_handler(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    await state.set_state(ReplaceRental.selecting_account)
    await state.update_data(rental_id=callback_data.item_id)
    
    db = SessionLocal()
    subquery = db.query(Rental.account_id, func.count(Rental.id).label('rent_count')).filter(Rental.end_time > datetime.datetime.now()).group_by(Rental.account_id).subquery()
    free_accounts = db.query(Account).outerjoin(subquery, Account.id == subquery.c.account_id).filter(func.coalesce(subquery.c.rent_count, 0) < Account.usage_limit).all()
    db.close()
    
    if not free_accounts:
        await callback.answer("❌ Нет свободных аккаунтов для замены!", show_alert=True)
        await state.clear()
        return

    await callback.message.edit_text(
        "Выберите новый аккаунт для замены:",
        reply_markup=select_account_for_replacement_menu(free_accounts, AdminCallback(level=1, action="view_renters").pack())
    )
    await callback.answer()

@router.callback_query(ReplaceRental.selecting_account, AdminCallback.filter(F.action == "select_replacement_acc"))
async def select_replacement_acc_handler(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    await state.update_data(new_account_id=callback_data.item_id)
    await state.set_state(ReplaceRental.confirming_replacement)
    
    data = await state.get_data()
    db = SessionLocal()
    old_rental = db.query(Rental).options(joinedload(Rental.account), joinedload(Rental.key)).filter(Rental.id == data['rental_id']).first()
    new_account = db.query(Account).filter(Account.id == data['new_account_id']).first()
    db.close()
    
    if not old_rental or not new_account:
        await callback.answer("❌ Ошибка: не найден старый или новый аккаунт.", show_alert=True)
        await state.clear()
        return

    text = (f"Подтвердите замену:\n\n"
            f"👤 Пользователь: {old_rental.key.activated_by_user_name if old_rental.key else 'N/A'}\n"
            f"🗑️ Старый аккаунт: `{old_rental.account.acc_id}`\n"
            f"✨ Новый аккаунт: `{new_account.acc_id}`\n\n"
            f"Оставшееся время аренды будет перенесено.")
    
    await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Заменить", callback_data="confirm_replacement")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data=AdminCallback(level=1, action="view_renters").pack())]
    ]), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(ReplaceRental.confirming_replacement, F.data == "confirm_replacement")
async def execute_replacement_handler(callback: CallbackQuery, state: FSMContext, bot: Bot):
    await callback.message.edit_text("⏳ Выполняю замену...")
    data = await state.get_data()
    
    db = SessionLocal()
    old_rental = db.query(Rental).options(joinedload(Rental.key), joinedload(Rental.account)).filter(Rental.id == data['rental_id']).first()
    
    if not old_rental:
        await callback.message.edit_text("❌ Ошибка: исходная аренда не найдена.")
        await state.clear()
        db.close()
        return

    user_id = old_rental.user_id
    remaining_time = old_rental.end_time - datetime.datetime.now()
    old_acc_id_str = old_rental.account.acc_id
    user_name = old_rental.key.activated_by_user_name if old_rental.key else 'N/A'
    pool_id = old_rental.key.pool_id if old_rental.key else None
    
    db.delete(old_rental)
    
    new_key = ActivationKey(
        key=str(uuid.uuid4()),
        duration_days=max(1, remaining_time.days),
        is_activated=True, activated_at=datetime.datetime.now(),
        activated_by_user_id=user_id, activated_by_user_name=user_name,
        pool_id=pool_id
    )
    db.add(new_key)
    db.flush()

    new_rental = Rental(
        user_id=user_id, account_id=data['new_account_id'],
        end_time=datetime.datetime.now() + remaining_time, key_id=new_key.id
    )
    db.add(new_rental)
    
    new_account = db.query(Account).filter(Account.id == data['new_account_id']).first()
    new_acc_id_str = new_account.acc_id
    
    db.commit()
    db.close()
    
    notification_text = (f"ℹ️ *ЗАМЕНА АККАУНТА*\n\n"
                         f"Администратор заменил ваш аккаунт `{old_acc_id_str}` на новый.\n\n"
                         f"Данные для входа доступны в разделе «Мои аренды».")
    try:
        await bot.send_message(user_id, notification_text, parse_mode="Markdown")
    except Exception as e:
        logging.warning(f"Не удалось уведомить пользователя {user_id} о замене: {e}")

    await callback.message.edit_text(f"✅ Аккаунт `{old_acc_id_str}` успешно заменен на `{new_acc_id_str}`!")
    await state.clear()
    
    cb_data = AdminCallback(level=1, action="view_renters", page=0)
    await view_renters_handler(callback, cb_data, state)

@router.callback_query(AdminCallback.filter(F.action == "revoke_rental"))
async def revoke_rental_handler(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext, bot: Bot):
    rental_id = callback_data.item_id
    db = SessionLocal()
    rental = db.query(Rental).options(joinedload(Rental.key), joinedload(Rental.account)).filter(Rental.id == rental_id).first()
    
    if not rental:
        await callback.answer("❌ Аренда не найдена.", show_alert=True)
        db.close()
        return

    user_id = rental.user_id
    acc_id_str = rental.account.acc_id
    
    if rental.key:
        db.delete(rental.key)
    else:
        db.delete(rental)
        
    db.commit()
    db.close()
    
    notification_text = f"ℹ️ Администратор досрочно завершил вашу аренду аккаунта `{acc_id_str}`."
    try:
        await bot.send_message(user_id, notification_text)
    except Exception as e:
        logging.warning(f"Не удалось уведомить пользователя {user_id} об отзыве аренды: {e}")
        
    await callback.answer(f"Аренда для аккаунта {acc_id_str} отозвана. Ключ удален.", show_alert=True)
    
    cb_data = AdminCallback(level=1, action="view_renters", page=callback_data.page)
    await view_renters_handler(callback, cb_data, state)

# --- Управление настройками ---
@router.callback_query(AdminCallback.filter(F.action == "settings"))
async def settings_handler(callback: CallbackQuery):
    await callback.message.edit_text("⚙️ Настройки бота:", reply_markup=settings_menu(settings_manager, get_admin_ids()))
    await callback.answer()

@router.callback_query(AdminCallback.filter(F.action == "toggle_setting"))
async def toggle_setting_handler(callback: CallbackQuery, callback_data: AdminCallback):
    setting_key = callback_data.value
    settings_manager[setting_key] = not settings_manager.get(setting_key, False)
    save_settings(settings_manager)
    await callback.message.edit_text("⚙️ Настройки бота:", reply_markup=settings_menu(settings_manager, get_admin_ids()))
    await callback.answer(f"Настройка '{setting_key}' изменена.")

@router.callback_query(AdminCallback.filter(F.action == "edit_maintenance_reason"))
async def edit_maintenance_reason_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(MaintenanceState.awaiting_reason)
    await callback.message.edit_text("Введите новую причину для режима тех. работ:", reply_markup=back_button(1, "settings"))

@router.message(MaintenanceState.awaiting_reason)
async def process_maintenance_reason(message: Message, state: FSMContext):
    settings_manager["maintenance_reason"] = message.text
    save_settings(settings_manager)
    await state.clear()
    await message.answer("✅ Причина обновлена.")
    await message.answer("⚙️ Настройки бота:", reply_markup=settings_menu(settings_manager, get_admin_ids()))

@router.callback_query(AdminCallback.filter(F.action == "add_admin"))
async def add_admin_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminManagement.awaiting_add)
    await callback.message.edit_text("Введите ID нового администратора:", reply_markup=back_button(1, "settings"))

@router.message(AdminManagement.awaiting_add)
async def process_add_admin(message: Message, state: FSMContext):
    if not message.text.isdigit():
        return await message.answer("❌ ID должен быть числом.")
    
    admin_id = int(message.text)
    if admin_id not in settings_manager['admin_ids']:
        settings_manager['admin_ids'].append(admin_id)
        save_settings(settings_manager)
        await message.answer(f"✅ Администратор {admin_id} добавлен.")
    else:
        await message.answer("Этот пользователь уже является администратором.")
    await state.clear()
    await message.answer("⚙️ Настройки бота:", reply_markup=settings_menu(settings_manager, get_admin_ids()))

@router.callback_query(AdminCallback.filter(F.action == "remove_admin_list"))
async def remove_admin_list_handler(callback: CallbackQuery):
    main_admin_id = int(os.getenv("ADMIN_ID", 0))
    await callback.message.edit_text(
        "Выберите администратора для удаления. Главного админа удалить нельзя.",
        reply_markup=remove_admin_menu(get_admin_ids(), main_admin_id)
    )

@router.callback_query(AdminCallback.filter(F.action == "remove_admin"))
async def remove_admin_confirm(callback: CallbackQuery, callback_data: AdminCallback):
    admin_id_to_remove = callback_data.item_id
    if admin_id_to_remove in settings_manager['admin_ids']:
        settings_manager['admin_ids'].remove(admin_id_to_remove)
        save_settings(settings_manager)
        await callback.answer(f"Администратор {admin_id_to_remove} удален.", show_alert=True)
    else:
        await callback.answer("Администратор не найден.", show_alert=True)
    
    await callback.message.edit_text("⚙️ Настройки бота:", reply_markup=settings_menu(settings_manager, get_admin_ids()))


# --- Управление аккаунтами ---
@router.callback_query(AdminCallback.filter(F.action == "view_accounts"))
async def view_accounts_handler(callback_or_message: types.CallbackQuery | types.Message, callback_data: AdminCallback, state: FSMContext):
    await state.clear()
    page = callback_data.page
    db = SessionLocal()
    total_items = db.query(Account).count()
    total_pages = ceil(total_items / PAGE_SIZE) if total_items > 0 else 1
    accounts = db.query(Account).order_by(Account.acc_id).limit(PAGE_SIZE).offset(page * PAGE_SIZE).all()
    db.close()
    
    message = callback_or_message.message if isinstance(callback_or_message, types.CallbackQuery) else callback_or_message
    
    try:
        await message.edit_text(
            "📒 Список аккаунтов:",
            reply_markup=accounts_menu(accounts, page, total_pages)
        )
    except exceptions.TelegramBadRequest:
        await message.answer("📒 Список аккаунтов:", reply_markup=accounts_menu(accounts, page, total_pages))

    if isinstance(callback_or_message, types.CallbackQuery):
        await callback_or_message.answer()

@router.callback_query(AdminCallback.filter(F.action == "replace_account_start"))
async def start_replace_account_data(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ReplaceAccountData.awaiting_data)
    text = ("🔄 **Замена данных аккаунта**\n\n"
            "Отправьте сообщение с новыми данными. Аренды, привязанные к ID, сохранятся.\n\n"
            "**Формат:**\n`id_аккаунта:новый_email_adobe:новый_пароль_adobe:новый_imap_сервер:новый_email_imap:новый_пароль_imap`")
    await callback.message.edit_text(text, reply_markup=back_button(1, "view_accounts"), parse_mode="Markdown")

@router.message(ReplaceAccountData.awaiting_data)
async def process_replace_account_data(message: Message, state: FSMContext):
    await state.clear()
    line = message.text.strip()
    parts = line.split(':')
    if len(parts) != 6:
        await message.answer("❌ **Ошибка!** Неверный формат данных. Требуется 6 полей, разделенных двоеточием.")
        return

    acc_id, email, password, imap_s, imap_e, imap_p = parts
    
    db = SessionLocal()
    account_to_update = db.query(Account).filter(Account.acc_id == acc_id).first()

    if not account_to_update:
        await message.answer(f"❌ **Ошибка!** Аккаунт с ID `{acc_id}` не найден.")
        db.close()
        return
    
    account_to_update.adobe_email = email
    account_to_update.adobe_password = password
    account_to_update.imap_server = imap_s
    account_to_update.imap_email = imap_e
    account_to_update.imap_password = imap_p
    
    db.commit()
    db.close()
    
    await message.answer(f"✅ Данные для аккаунта `{acc_id}` успешно обновлены!")
    export_accounts_to_json()
    
    await view_accounts_handler(message, AdminCallback(page=0, action="view_accounts"), state)

@router.callback_query(AdminCallback.filter(F.action.in_({"edit_login", "edit_password", "edit_adobe_email", "edit_imap_password", "edit_imap_server"})))
async def start_edit_account_field(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    await state.set_state(EditAccount.awaiting_value)
    field_map = {
        "edit_login": ("acc_id", "ID аккаунта"),
        "edit_password": ("adobe_password", "пароль Adobe"),
        "edit_adobe_email": ("adobe_email", "Email Adobe"),
        "edit_imap_password": ("imap_password", "пароль Email"),
        "edit_imap_server": ("imap_server", "IMAP сервер")
    }
    action = callback_data.action
    if action not in field_map: return
    field, prompt = field_map[action]
    await state.update_data(account_id=callback_data.item_id, field_to_edit=field)
    await callback.message.edit_text(f"Введите новый **{prompt}**:", reply_markup=back_button(2, "view_account", callback_data.item_id), parse_mode="Markdown")
    await callback.answer()
    
@router.message(EditAccount.awaiting_value)
async def process_edit_account_value(message: Message, state: FSMContext):
    data = await state.get_data()
    account_id = data.get("account_id")
    field = data.get("field_to_edit")
    new_value = message.text.strip()
    
    db = SessionLocal()
    account = db.query(Account).filter(Account.id == account_id).first()
    if account:
        setattr(account, field, new_value)
        db.commit()
        await message.answer(f"✅ Данные для аккаунта `{account.acc_id}` обновлены.")
    else:
        await message.answer("❌ Аккаунт не найден.")
    db.close()
    await state.clear()
    
    export_accounts_to_json()
    await view_single_account(message, AdminCallback(level=2, action="view_account", item_id=account_id), state)

@router.callback_query(AdminCallback.filter(F.action == "bulk_add"))
async def start_bulk_add(callback: CallbackQuery, state: FSMContext):
    await state.set_state(BulkAddAccounts.awaiting_message)
    text = ("📥 **Массовая загрузка**\n\n"
            "Отправьте сообщение со списком аккаунтов. Каждый на новой строке.\n\n"
            "**Формат:**\n`id:adobe_email:adobe_pass:imap_server:imap_email:imap_pass`")
    await callback.message.edit_text(text, reply_markup=back_button(1, "view_accounts"), parse_mode="Markdown")

@router.message(BulkAddAccounts.awaiting_message)
async def process_bulk_add(message: Message, state: FSMContext):
    await state.clear()
    lines = message.text.strip().split('\n')
    added_count, errors = 0, []
    db = SessionLocal()
    existing_ids_query = db.query(Account.acc_id).all()
    existing_ids = {acc_id for (acc_id,) in existing_ids_query}
    for i, line in enumerate(lines):
        if not (line := line.strip()): continue
        parts = line.split(':')
        if len(parts) != 6:
            errors.append(f"Стр. {i+1}: неверный формат.")
            continue
        acc_id, email, password, imap_s, imap_e, imap_p = parts
        if acc_id in existing_ids:
            errors.append(f"Стр. {i+1}: ID '{acc_id}' уже существует.")
            continue
        db.add(Account(acc_id=acc_id, adobe_email=email, adobe_password=password, imap_server=imap_s, imap_email=imap_e, imap_password=imap_p))
        existing_ids.add(acc_id)
        added_count += 1
    db.commit()
    db.close()
    report = f"✅ **Загрузка завершена**\n\nДобавлено: {added_count} акк."
    if errors: report += f"\n❌ Ошибки ({len(errors)}):\n- " + "\n- ".join(errors[:15])
    await message.answer(report, reply_markup=back_button(1, "view_accounts"), parse_mode="Markdown")
    if added_count > 0: export_accounts_to_json()
    
@router.callback_query(AdminCallback.filter(F.action == "check_imap"))
async def check_imap_handler(callback: CallbackQuery):
    await callback.message.edit_text("⏳ Начинаю проверку IMAP всех аккаунтов. Это может занять время...")
    
    db = SessionLocal()
    accounts = db.query(Account).all()
    db.close()
    
    results = []
    for acc in accounts:
        code = get_adobe_code(acc.imap_server, acc.imap_email, acc.imap_password, check_only=True)
        status = "✅ OK" if code == "OK" else f"❌ Ошибка"
        results.append(f"`{acc.acc_id}` - {status}")
    
    report = "🏁 **Проверка IMAP завершена:**\n\n" + "\n".join(results)
    await callback.message.edit_text(report, reply_markup=back_button(1, "view_accounts"), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(AdminCallback.filter(F.action == "bulk_delete_accs"))
async def start_bulk_delete_accs(callback: CallbackQuery, state: FSMContext):
    await state.set_state(BulkDeleteAccounts.selecting)
    await state.update_data(selected_ids=[], page=0)
    
    db = SessionLocal()
    accounts = db.query(Account).order_by(Account.acc_id).all()
    db.close()
    
    total_pages = ceil(len(accounts) / PAGE_SIZE) if accounts else 1
    await state.update_data(all_acc_ids=[str(acc.id) for acc in accounts])
    
    text = f"🗑️ **Массовое удаление аккаунтов**\nВыберите аккаунты для удаления. Выбрано: 0"
    await callback.message.edit_text(
        text, 
        reply_markup=bulk_delete_accounts_menu(accounts, [], 0, total_pages)
    )
    await callback.answer()

@router.callback_query(BulkDeleteAccounts.selecting, AdminCallback.filter(F.action == "bulk_delete_accs_page"))
async def paginate_bulk_delete_accs(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    data = await state.get_data()
    selected_ids = data.get("selected_ids", [])
    page = callback_data.page
    await state.update_data(page=page)

    db = SessionLocal()
    accounts = db.query(Account).order_by(Account.acc_id).all()
    db.close()
    
    total_pages = ceil(len(accounts) / PAGE_SIZE) if accounts else 1

    await callback.message.edit_text(
        f"🗑️ **Массовое удаление аккаунтов**\nВыберите аккаунты для удаления. Выбрано: {len(selected_ids)}",
        reply_markup=bulk_delete_accounts_menu(accounts, selected_ids, page, total_pages)
    )
    await callback.answer()

@router.callback_query(BulkDeleteAccounts.selecting, AdminCallback.filter(F.action == "toggle_account_selection"))
async def toggle_account_selection_handler(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    acc_id = str(callback_data.item_id)
    data = await state.get_data()
    selected_ids = data.get("selected_ids", [])
    page = data.get("page", 0)
    
    if acc_id in selected_ids:
        selected_ids.remove(acc_id)
    else:
        selected_ids.append(acc_id)
    await state.update_data(selected_ids=selected_ids)
    
    db = SessionLocal()
    accounts = db.query(Account).order_by(Account.acc_id).all()
    db.close()
    
    total_pages = ceil(len(accounts) / PAGE_SIZE) if accounts else 1
    
    await callback.message.edit_text(
        f"🗑️ **Массовое удаление аккаунтов**\nВыберите аккаунты для удаления. Выбрано: {len(selected_ids)}",
        reply_markup=bulk_delete_accounts_menu(accounts, selected_ids, page, total_pages)
    )
    await callback.answer()

@router.callback_query(BulkDeleteAccounts.selecting, AdminCallback.filter(F.action.in_({"select_all_accs", "deselect_all_accs"})))
async def select_deselect_all_accs(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    data = await state.get_data()
    if callback_data.action == "select_all_accs":
        await state.update_data(selected_ids=data.get("all_acc_ids", []))
    else:
        await state.update_data(selected_ids=[])

    new_data = await state.get_data()
    selected_ids = new_data.get("selected_ids", [])
    page = new_data.get('page', 0)

    db = SessionLocal()
    accounts = db.query(Account).order_by(Account.acc_id).all()
    db.close()

    total_pages = ceil(len(accounts) / PAGE_SIZE) if accounts else 1

    await callback.message.edit_text(
        f"🗑️ **Массовое удаление аккаунтов**\nВыберите аккаунты для удаления. Выбрано: {len(selected_ids)}",
        reply_markup=bulk_delete_accounts_menu(accounts, selected_ids, page, total_pages)
    )
    await callback.answer()

@router.callback_query(AdminCallback.filter(F.action == "view_status"))
async def view_account_status(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    db = SessionLocal()
    all_pools = db.query(Pool).options(joinedload(Pool.accounts).joinedload(AccountPoolLink.account)).all()
    active_rentals = db.query(Rental.account_id, func.count(Rental.id)).filter(
        Rental.end_time > datetime.datetime.now()
    ).group_by(Rental.account_id).all()
    
    rentals_count = dict(active_rentals)
    
    text = "📊 <b>Статус аккаунтов по пулам:</b>\n\n"
    if not all_pools:
        text += "<i>Пулы еще не созданы.</i>"
    else:
        for pool in all_pools:
            pool_text = ""
            total_slots, total_used_slots = 0, 0
            for link in pool.accounts:
                if not link.account: continue
                used_slots = rentals_count.get(link.account.id, 0)
                limit = link.account.usage_limit
                total_slots += limit
                total_used_slots += used_slots
                status_icon = "✅" if used_slots < limit else "❌"
                pool_text += f"▪️ <code>{link.account.acc_id}</code> - {status_icon} Занято ({used_slots}/{limit})\n"
            text += f"🗂️ <b>Пул: {pool.name}</b> ({total_used_slots}/{total_slots} занято)\n{pool_text}\n"
    db.close()
    await callback.message.edit_text(text, reply_markup=back_button(0, "main_menu"))

@router.callback_query(AdminCallback.filter(F.action == "add_account"))
async def add_account_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AddAccount.acc_id)
    await callback.message.edit_text("<b>Шаг 1/6:</b> Введите ID аккаунта (e.g., <code>adobe1</code>):", reply_markup=back_button(1, "view_accounts"))

@router.message(AddAccount.acc_id)
async def p_acc_id(message: Message, state: FSMContext):
    await state.update_data(acc_id=message.text)
    await state.set_state(AddAccount.adobe_email)
    await message.answer("<b>2/6:</b> Email Adobe.")
@router.message(AddAccount.adobe_email)
async def p_adobe_email(message: Message, state: FSMContext):
    await state.update_data(adobe_email=message.text)
    await state.set_state(AddAccount.adobe_password)
    await message.answer("<b>3/6:</b> Пароль Adobe.")
@router.message(AddAccount.adobe_password)
async def p_adobe_pass(message: Message, state: FSMContext):
    await state.update_data(adobe_password=message.text)
    await state.set_state(AddAccount.imap_server)
    await message.answer("<b>4/6:</b> IMAP сервер.")
@router.message(AddAccount.imap_server)
async def p_imap_server(message: Message, state: FSMContext):
    await state.update_data(imap_server=message.text)
    await state.set_state(AddAccount.imap_email)
    await message.answer("<b>5/6:</b> Email почты.")
@router.message(AddAccount.imap_email)
async def p_imap_email(message: Message, state: FSMContext):
    await state.update_data(imap_email=message.text)
    await state.set_state(AddAccount.imap_password)
    await message.answer("<b>6/6:</b> Пароль почты.")
@router.message(AddAccount.imap_password)
async def p_imap_pass(message: Message, state: FSMContext):
    data = await state.get_data()
    data["imap_password"] = message.text
    db = SessionLocal()
    db.add(Account(**data))
    db.commit()
    acc_id = data.get('acc_id')
    db.close()
    await state.clear()
    await message.answer(f"✅ Аккаунт <code>{acc_id}</code> добавлен!")
    
    export_accounts_to_json()

    await view_accounts_handler(message, AdminCallback(page=0, action="view_accounts"), state)
    
@router.callback_query(AdminCallback.filter(F.action == "view_account"))
async def view_single_account(callback_or_message: types.CallbackQuery | types.Message, callback_data: AdminCallback, state: FSMContext):
    await state.clear()
    
    message = callback_or_message.message if isinstance(callback_or_message, types.CallbackQuery) else callback_or_message

    db=SessionLocal(); acc=db.query(Account).filter(Account.id==callback_data.item_id).first(); db.close()
    if not acc: 
        await message.answer("Аккаунт не найден!")
        return

    text=(f"<b>ID:</b> <code>{acc.acc_id}</code>\n"
          f"<b>Лимит использования:</b> {acc.usage_limit}\n"
          f"<b>Adobe:</b> <code>{acc.adobe_email}:{acc.adobe_password}</code>\n"
          f"<b>IMAP:</b> <code>{acc.imap_server} | {acc.imap_email}:{acc.imap_password}</code>")
          
    try:
        await message.edit_text(text, reply_markup=single_account_menu(acc.id))
    except exceptions.TelegramBadRequest:
        await message.answer(text, reply_markup=single_account_menu(acc.id))
    
    if isinstance(callback_or_message, types.CallbackQuery):
        await callback_or_message.answer()


@router.callback_query(AdminCallback.filter(F.action == "set_limit"))
async def set_limit_start(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    await state.set_state(SetLimitState.awaiting_limit)
    await state.update_data(account_id=callback_data.item_id)
    await callback.message.edit_text("Введите новый лимит использования для этого аккаунта (например, 1, 3, 5):", reply_markup=back_button(2, 'view_account', callback_data.item_id))
    await callback.answer()

@router.message(SetLimitState.awaiting_limit)
async def process_new_limit(message: Message, state: FSMContext):
    if not message.text.isdigit() or int(message.text) < 1:
        await message.answer("❌ Пожалуйста, введите целое число больше 0.")
        return
    limit = int(message.text)
    data = await state.get_data()
    account_id = data.get("account_id")
    
    db = SessionLocal()
    account = db.query(Account).filter(Account.id == account_id).first()
    if account:
        account.usage_limit = limit
        db.commit()
        await message.answer(f"✅ Лимит для аккаунта <code>{account.acc_id}</code> установлен на {limit}.")
    else:
        await message.answer("❌ Аккаунт не найден.")
    db.close()
    await state.clear()

    await view_single_account(message, AdminCallback(level=2, action="view_account", item_id=account_id), state)

@router.callback_query(AdminCallback.filter(F.action == "get_code"))
async def get_code_admin(callback: CallbackQuery, callback_data: AdminCallback):
    db=SessionLocal(); acc=db.query(Account).filter(Account.id==callback_data.item_id).first(); db.close()
    if not acc: return await callback.answer("Аккаунт не найден!", True)
    await callback.answer("⏳ Запрашиваю код...", False)
    code = get_adobe_code(acc.imap_server, acc.imap_email, acc.imap_password)
    await callback.message.answer(f"Код для <code>{acc.acc_id}</code>:\n<code>{code}</code>")

@router.callback_query(AdminCallback.filter(F.action == "delete_account"))
async def delete_account(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    db=SessionLocal()
    acc=db.query(Account).filter(Account.id==callback_data.item_id).first()
    if acc: 
        db.delete(acc)
        db.commit()
        export_accounts_to_json()
        export_pools_to_json() 
    db.close()
    await callback.answer("Аккаунт удален!", True)
    cb_data = AdminCallback(level=1, action="view_accounts", page=0)
    await view_accounts_handler(callback, cb_data, state)

# --- Управление пулами ---
@router.callback_query(AdminCallback.filter(F.action == "view_pools"))
async def view_pools_handler(callback_or_message: types.CallbackQuery | types.Message, callback_data: AdminCallback):
    page = callback_data.page
    db=SessionLocal()
    total_items = db.query(Pool).count()
    total_pages = ceil(total_items / PAGE_SIZE) if total_items > 0 else 1
    all_pools=db.query(Pool).options(joinedload(Pool.accounts)).order_by(Pool.name).limit(PAGE_SIZE).offset(page * PAGE_SIZE).all()
    db.close()

    message = callback_or_message.message if isinstance(callback_or_message, types.CallbackQuery) else callback_or_message
    await message.edit_text(
        "🗂️ Управление пулами:", 
        reply_markup=pools_menu(all_pools, page, total_pages)
    )
    if isinstance(callback_or_message, types.CallbackQuery):
        await callback_or_message.answer()

@router.callback_query(AdminCallback.filter(F.action == "add_pool"))
async def add_pool_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AddPool.name)
    await callback.message.edit_text("Имя нового пула:", reply_markup=back_button(1,"view_pools"))

@router.message(AddPool.name)
async def process_pool_name(message: Message, state: FSMContext):
    db=SessionLocal()
    db.add(Pool(name=message.text.strip()))
    db.commit()
    db.close()
    await state.clear()
    await message.answer(f"✅ Пул `{message.text.strip()}` создан.")
    export_pools_to_json()
    await view_pools_handler(message, AdminCallback(action="view_pools", page=0))
    
@router.callback_query(AdminCallback.filter(F.action == "view_pool"))
async def view_single_pool(callback_or_message: types.CallbackQuery | types.Message, callback_data: AdminCallback):
    # Эта строка делает функцию универсальной
    message = callback_or_message.message if isinstance(callback_or_message, types.CallbackQuery) else callback_or_message

    db=SessionLocal()
    pool=db.query(Pool).options(joinedload(Pool.accounts).joinedload(AccountPoolLink.account)).filter(Pool.id==callback_data.item_id).first()
    db.close()
    if not pool: 
        await message.answer("Пул не найден!")
        # Если это callback, отвечаем на него
        if isinstance(callback_or_message, types.CallbackQuery):
            await callback_or_message.answer()
        return

    text=f"<b>Пул: {pool.name}</b>\n\nАккаунты:"
    acc_lines = "\n".join(f"- <code>{link.account.acc_id}</code>" for link in pool.accounts if link.account)
    text += f"\n{acc_lines}" if acc_lines else "\n<i>(пусто)</i>"
    
    try:
        await message.edit_text(text, reply_markup=single_pool_menu(pool))
    except exceptions.TelegramBadRequest:
        # Эта часть нужна, если текст и кнопки не изменились, или если это было не inline-сообщение
        await message.answer(text, reply_markup=single_pool_menu(pool))

    # Отвечаем на callback, если он был
    if isinstance(callback_or_message, types.CallbackQuery):
        await callback_or_message.answer()

@router.callback_query(AdminCallback.filter(F.action == "list_acc_for_removal"))
async def list_accounts_for_removal_handler(callback: CallbackQuery, callback_data: AdminCallback):
    db = SessionLocal()
    pool = db.query(Pool).options(joinedload(Pool.accounts).joinedload(AccountPoolLink.account)).filter(Pool.id == callback_data.item_id).first()
    db.close()
    if not pool: return await callback.answer("Пул не найден!", show_alert=True)
    back_cb = AdminCallback(level=2, action="view_pool", item_id=pool.id).pack()
    await callback.message.edit_text("Выберите аккаунт для удаления из пула:", reply_markup=list_accounts_for_removal_menu(pool, back_cb))
    await callback.answer()

@router.callback_query(AdminCallback.filter(F.action == "add_acc_to_pool"))
async def add_acc_to_pool_start(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    await state.set_data({'pool_id': callback_data.item_id})
    await state.set_state(AddAccountToPool.acc_id)
    await callback.message.edit_text("ID аккаунта для добавления:", reply_markup=back_button(2, "view_pool", callback_data.item_id))

@router.message(AddAccountToPool.acc_id)
async def process_add_acc_to_pool(message: Message, state: FSMContext):
    data = await state.get_data()
    db = SessionLocal()
    acc = db.query(Account).filter(Account.acc_id==message.text.strip()).first()
    if not acc:
        await message.answer("❌ Аккаунт не найден.")
        db.close()
        return
    if db.query(AccountPoolLink).filter_by(account_id=acc.id, pool_id=data['pool_id']).first():
        await message.answer("❌ Этот аккаунт уже в пуле.")
        db.close()
        return
    db.add(AccountPoolLink(account_id=acc.id, pool_id=data['pool_id']))
    db.commit()
    export_pools_to_json()
    await message.answer(f"✅ Аккаунт `{acc.acc_id}` добавлен в пул.")
    await state.clear()
    
    await view_single_pool(message, AdminCallback(level=2, action="view_pool", item_id=data['pool_id']))
    db.close()

@router.callback_query(AdminCallback.filter(F.action == "remove_acc_from_pool"))
async def remove_acc_from_pool(callback: CallbackQuery, callback_data: AdminCallback):
    db=SessionLocal()
    link=db.query(AccountPoolLink).filter(AccountPoolLink.id==callback_data.item_id).first()
    if link:
        pool_id_to_return = link.pool_id
        db.delete(link)
        db.commit()
        export_pools_to_json()
        await callback.answer("Аккаунт убран из пула!", False)
        refreshed_callback_data = AdminCallback(level=2, action="view_pool", item_id=pool_id_to_return)
        await view_single_pool(callback, refreshed_callback_data)
    else:
        await callback.answer("Связь уже удалена.", True)
    db.close()

@router.callback_query(AdminCallback.filter(F.action == "delete_pool"))
async def delete_pool_handler(callback: CallbackQuery, callback_data: AdminCallback):
    db=SessionLocal()
    pool=db.query(Pool).filter(Pool.id==callback_data.item_id).first()
    if pool: 
        db.delete(pool)
        db.commit()
        export_pools_to_json()
    db.close()
    await callback.answer("Пул удален!", True)
    cb_data = AdminCallback(level=1, action="view_pools", page=0)
    await view_pools_handler(callback, cb_data)

# --- Управление очередью ожидания ---
@router.callback_query(AdminCallback.filter(F.action == "view_waiting_list"))
async def view_waiting_list_handler(callback_or_message: types.CallbackQuery | types.Message, callback_data: AdminCallback, state: FSMContext):
    await state.clear()
    page = callback_data.page
    db = SessionLocal()
    
    query = db.query(WaitingList).options(joinedload(WaitingList.pool), joinedload(WaitingList.key))
    total_items = query.count()
    total_pages = ceil(total_items / PAGE_SIZE) if total_items > 0 else 1
    
    waiters = query.order_by(WaitingList.added_at).limit(PAGE_SIZE).offset(page * PAGE_SIZE).all()
    db.close()
    
    message = callback_or_message.message if isinstance(callback_or_message, types.CallbackQuery) else callback_or_message
    
    await message.edit_text(
        "⏳ Очередь ожидания:",
        reply_markup=waiting_list_menu(waiters, page, total_pages)
    )
    if isinstance(callback_or_message, types.CallbackQuery):
        await callback_or_message.answer()

@router.callback_query(AdminCallback.filter(F.action == "view_waiter"))
async def view_single_waiter_handler(callback: CallbackQuery, callback_data: AdminCallback):
    db = SessionLocal()
    waiter = db.query(WaitingList).options(joinedload(WaitingList.key), joinedload(WaitingList.pool)).filter(WaitingList.id == callback_data.item_id).first()
    db.close()

    if not waiter:
        await callback.answer("❌ Запись в очереди не найдена.", show_alert=True)
        return

    text = (f"👤 **Пользователь в очереди**\n\n"
            f"<b>Имя:</b> {waiter.user_name}\n"
            f"<b>User ID:</b> <code>{waiter.user_id}</code>\n"
            f"<b>Пытался активировать ключ:</b> <code>{waiter.key.key if waiter.key else 'N/A'}</code>\n"
            f"<b>Для пула:</b> {waiter.pool.name if waiter.pool else 'N/A'}\n"
            f"<b>Добавлен в очередь:</b> {waiter.added_at.strftime('%d.%m.%Y %H:%M')}")
            
    await callback.message.edit_text(text, reply_markup=single_waiter_menu(waiter.id))
    await callback.answer()

@router.callback_query(AdminCallback.filter(F.action == "remove_from_waitlist"))
async def remove_from_waitlist_handler(callback: CallbackQuery, callback_data: AdminCallback, bot: Bot, state: FSMContext):
    db = SessionLocal()
    waiter = db.query(WaitingList).filter(WaitingList.id == callback_data.item_id).first()
    if waiter:
        user_id_to_notify = waiter.user_id
        db.delete(waiter)
        db.commit()
        await callback.answer("Пользователь удален из очереди.", show_alert=True)
        try:
            await bot.send_message(user_id_to_notify, "Администратор удалил вас из очереди ожидания.")
        except Exception as e:
            logging.warning(f"Не удалось уведомить пользователя {user_id_to_notify} об удалении из очереди: {e}")
    else:
        await callback.answer("❌ Запись уже удалена.", show_alert=True)
    db.close()
    await view_waiting_list_handler(callback, AdminCallback(level=1, page=0, action="view_waiting_list"), state)

@router.callback_query(AdminCallback.filter(F.action == "manual_assign"))
async def manual_assign_handler(callback: CallbackQuery, callback_data: AdminCallback, bot: Bot, state: FSMContext):
    await callback.answer("⏳ Пытаюсь активировать аренду...")
    db = SessionLocal()
    waiter = db.query(WaitingList).options(joinedload(WaitingList.key).joinedload(ActivationKey.pool)).filter(WaitingList.id == callback_data.item_id).first()

    if not waiter or not waiter.key or not waiter.key.pool:
        await callback.answer("❌ Ошибка: запись в очереди, связанный ключ или пул не найдены.", show_alert=True)
        db.close()
        return
    
    key_obj = waiter.key
    target_pool = key_obj.pool
    
    target_account = None
    if target_pool.accounts:
        account_ids_in_pool = [link.account_id for link in target_pool.accounts if link.account_id]
        
        rentals_count_query = db.query(Rental.account_id, func.count(Rental.id)).filter(
            Rental.account_id.in_(account_ids_in_pool),
            Rental.end_time > datetime.datetime.now()
        ).group_by(Rental.account_id).all()
        rentals_count = dict(rentals_count_query)
        
        accounts_in_pool = db.query(Account).filter(Account.id.in_(account_ids_in_pool)).all()
        
        for acc in accounts_in_pool:
            current_rents = rentals_count.get(acc.id, 0)
            if current_rents < acc.usage_limit:
                target_account = acc
                break
    
    if target_account is None:
        await callback.answer("❌ Свободных аккаунтов в пуле по-прежнему нет.", show_alert=True)
        db.close()
        return

    end_time = datetime.datetime.now() + datetime.timedelta(days=key_obj.duration_days)
    new_rental = Rental(user_id=waiter.user_id, account_id=target_account.id, end_time=end_time, key_id=key_obj.id)
    db.add(new_rental)
    
    key_obj.is_activated = True
    key_obj.activated_by_user_id = waiter.user_id
    key_obj.activated_by_user_name = waiter.user_name
    key_obj.activated_at = datetime.datetime.now()
    
    db.delete(waiter)
    db.commit()

    await callback.message.edit_text(f"✅ Аренда для {waiter.user_name} успешно активирована на аккаунт `{target_account.acc_id}`!")
    
    try:
        await bot.send_message(waiter.user_id, f"🎉 Ваша аренда была активирована администратором! Проверьте раздел 'Мои аренды'.")
    except Exception as e:
        logging.warning(f"Не удалось уведомить пользователя {waiter.user_id} о ручной активации: {e}")
        
    db.close()
    
# --- Управление поддержкой ---
@router.callback_query(AdminCallback.filter(F.action == "support"))
async def support_main_menu(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("🎫 Управление поддержкой", reply_markup=support_admin_menu())

@router.callback_query(AdminCallback.filter(F.action.in_({"view_tickets", "view_appeals"})))
async def view_tickets_handler(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    await state.clear()
    action_type = callback_data.value
    page = callback_data.page
    
    db = SessionLocal()
    query = db.query(SupportTicket).options(joinedload(SupportTicket.messages))
    
    if callback_data.action == "view_appeals":
        query = query.filter(SupportTicket.is_appeal == True, SupportTicket.is_closed == False)
        title_text = "📜 Активные апелляции"
    else:
        is_closed = action_type == "closed"
        query = query.filter(SupportTicket.is_closed == is_closed, SupportTicket.is_appeal == False)
        title_text = "🗃️ Закрытые тикеты" if is_closed else "📬 Открытые тикеты"

    total_items = query.count()
    total_pages = ceil(total_items / PAGE_SIZE) if total_items > 0 else 1
    tickets = query.order_by(desc(SupportTicket.created_at)).limit(PAGE_SIZE).offset(page * PAGE_SIZE).all()
    db.close()
    
    if not tickets and page == 0: title_text += "\n\n<i>(Пусто)</i>"
    await callback.message.edit_text(title_text, reply_markup=view_tickets_menu(tickets, page, total_pages, action_type if callback_data.action == "view_tickets" else "appeals"))
    await callback.answer()

@router.callback_query(AdminCallback.filter(F.action == "bulk_delete_tickets"))
async def start_bulk_delete_tickets(callback: CallbackQuery, state: FSMContext):
    await state.set_state(BulkDeleteTickets.selecting)
    await state.update_data(selected_ids=[], page=0)
    
    db = SessionLocal()
    all_tickets = db.query(SupportTicket).filter(SupportTicket.is_closed == True).order_by(desc(SupportTicket.created_at)).all()
    db.close()

    total_items = len(all_tickets)
    total_pages = ceil(total_items / PAGE_SIZE) if total_items > 0 else 1
    
    await state.update_data(all_ticket_ids=[str(t.id) for t in all_tickets])

    text = f"🗑️ **Массовое удаление закрытых тикетов**\nВыберите тикеты для удаления. Выбрано: 0"
    await callback.message.edit_text(
        text, 
        reply_markup=bulk_delete_tickets_menu(all_tickets, [], 0, total_pages)
    )
    await callback.answer()

@router.callback_query(BulkDeleteTickets.selecting, AdminCallback.filter(F.action == "bulk_delete_tickets_page"))
async def paginate_bulk_delete_tickets(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    data = await state.get_data()
    selected_ids = data.get("selected_ids", [])
    page = callback_data.page
    await state.update_data(page=page)

    db = SessionLocal()
    all_tickets = db.query(SupportTicket).filter(SupportTicket.is_closed == True).order_by(desc(SupportTicket.created_at)).all()
    db.close()
    
    total_pages = ceil(len(all_tickets) / PAGE_SIZE) if all_tickets else 1

    await callback.message.edit_text(
        f"🗑️ **Массовое удаление закрытых тикетов**\nВыберите тикеты для удаления. Выбрано: {len(selected_ids)}",
        reply_markup=bulk_delete_tickets_menu(all_tickets, selected_ids, page, total_pages)
    )
    await callback.answer()

@router.callback_query(BulkDeleteTickets.selecting, AdminCallback.filter(F.action == "toggle_ticket_selection"))
async def toggle_ticket_selection_handler(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    ticket_id = str(callback_data.item_id)
    data = await state.get_data()
    selected_ids = data.get("selected_ids", [])
    page = data.get("page", 0)
    
    if ticket_id in selected_ids:
        selected_ids.remove(ticket_id)
    else:
        selected_ids.append(ticket_id)
    await state.update_data(selected_ids=selected_ids)
    
    db = SessionLocal()
    all_tickets = db.query(SupportTicket).filter(SupportTicket.is_closed == True).order_by(desc(SupportTicket.created_at)).all()
    db.close()
    
    total_pages = ceil(len(all_tickets) / PAGE_SIZE) if all_tickets else 1
    
    await callback.message.edit_text(
        f"🗑️ **Массовое удаление закрытых тикетов**\nВыберите тикеты для удаления. Выбрано: {len(selected_ids)}",
        reply_markup=bulk_delete_tickets_menu(all_tickets, selected_ids, page, total_pages)
    )
    await callback.answer()

@router.callback_query(BulkDeleteTickets.selecting, AdminCallback.filter(F.action.in_({"select_all_tickets", "deselect_all_tickets"})))
async def select_deselect_all_tickets_handler(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    data = await state.get_data()
    if callback_data.action == "select_all_tickets":
        await state.update_data(selected_ids=data.get("all_ticket_ids", []))
    else:
        await state.update_data(selected_ids=[])

    new_data = await state.get_data()
    selected_ids = new_data.get("selected_ids", [])
    page = new_data.get('page', 0)

    db = SessionLocal()
    all_tickets = db.query(SupportTicket).filter(SupportTicket.is_closed == True).order_by(desc(SupportTicket.created_at)).all()
    db.close()

    total_pages = ceil(len(all_tickets) / PAGE_SIZE) if all_tickets else 1

    await callback.message.edit_text(
        f"🗑️ **Массовое удаление закрытых тикетов**\nВыберите тикеты для удаления. Выбрано: {len(selected_ids)}",
        reply_markup=bulk_delete_tickets_menu(all_tickets, selected_ids, page, total_pages)
    )
    await callback.answer()

@router.callback_query(BulkDeleteTickets.selecting, AdminCallback.filter(F.action == "confirm_bulk_delete_tickets"))
async def confirm_bulk_delete_tickets_handler(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    selected_ids = data.get("selected_ids", [])
    if not selected_ids:
        await callback.answer("⚠️ Тикеты не выбраны.", show_alert=True)
        return

    db = SessionLocal()
    db.query(SupportTicket).filter(SupportTicket.id.in_([int(i) for i in selected_ids])).delete(synchronize_session=False)
    db.commit()
    db.close()

    await callback.answer(f"✅ Удалено {len(selected_ids)} тикет(ов).", show_alert=True)
    await state.clear()
    
    await support_main_menu(callback, state)

async def send_ticket_view(bot: Bot, chat_id: int, ticket_id: int):
    db = SessionLocal()
    ticket = db.query(SupportTicket).options(joinedload(SupportTicket.messages)).filter(SupportTicket.id == ticket_id).first()
    if not ticket:
        await bot.send_message(chat_id, "Ошибка: тикет не найден.")
        db.close()
        return

    history = ""
    for msg in sorted(ticket.messages, key=lambda m: m.created_at):
        sender = "👤 Пользователь" if msg.sender_type == 'user' else "🤖 Администратор"
        time_str = msg.created_at.strftime('%d.%m %H:%M')
        history += f"\n--- {sender} ({time_str}) ---\n"
        if msg.message_text:
            history += msg.message_text
        if msg.photo_file_id:
            history += f"<i>[Изображение отправлено]</i>"
    
    ticket_data = {
        "id": ticket.id, "is_closed": ticket.is_closed, "user_name": ticket.user_name, 
        "user_id": ticket.user_id, "created_at": ticket.created_at.strftime('%d.%m.%Y %H:%M'),
        "is_appeal": ticket.is_appeal
    }
    db.close()

    title = "❗️Апелляция" if ticket_data["is_appeal"] else "Обращение"
    text = (f"🎫 <b>{title} #{ticket_data['id']}</b>\n"
            f"<b>Статус:</b> {'Закрыт' if ticket_data['is_closed'] else 'Открыт'}\n"
            f"<b>От:</b> {ticket_data['user_name']} (<code>{ticket_data['user_id']}</code>)\n"
            f"<b>Создан:</b> {ticket_data['created_at']}\n"
            f"<b>История переписки:</b>\n{history}")
            
    await bot.send_message(chat_id, text, reply_markup=single_ticket_menu_admin(ticket_data['id'], ticket_data['user_id'], ticket_data['is_closed'], ticket_data['is_appeal']), disable_web_page_preview=True)

@router.callback_query(AdminCallback.filter(F.action == "view_ticket"))
async def view_single_ticket_handler(callback: CallbackQuery, callback_data: AdminCallback):
    try:
        await callback.message.delete()
    except Exception:
        pass
    await send_ticket_view(callback.bot, callback.from_user.id, callback_data.item_id)
    await callback.answer()


@router.callback_query(AdminCallback.filter(F.action == "reply_to_ticket"))
async def start_ticket_reply_handler(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    ticket_id = callback_data.item_id
    await state.set_state(SupportReplyState.awaiting_reply_message)
    await state.update_data(ticket_id=ticket_id)
    try:
        await callback.message.delete()
    except: pass
    await callback.message.answer(
        f"✏️ Введите ваш ответ на тикет #{ticket_id} (можно отправить фото):",
        reply_markup=back_button(level=3, action="view_ticket", item_id=ticket_id)
    )
    await callback.answer()

@router.message(SupportReplyState.awaiting_reply_message, F.content_type.in_([types.ContentType.TEXT, types.ContentType.PHOTO]))
async def process_ticket_reply_handler(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    ticket_id = data.get("ticket_id")
    await state.clear()
    
    try:
        if message.reply_to_message:
            await bot.delete_message(chat_id=message.chat.id, message_id=message.reply_to_message.message_id)
        await message.delete()
    except: pass
        
    db = SessionLocal()
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
    
    if not ticket:
        await message.answer("❌ Не удалось найти тикет.")
        db.close()
        return

    user_id_to_reply = ticket.user_id
    
    new_message = TicketMessage(
        ticket_id=ticket.id, sender_type='admin',
        message_text=message.text or message.caption,
        photo_file_id=message.photo[-1].file_id if message.photo else None
    )
    db.add(new_message)
    db.commit()
    db.close()
    export_tickets_to_json()
    
    try:
        reply_text = f"✉️ <b>Ответ от поддержки по обращению #{ticket_id}</b>"
        if message.photo:
            await bot.send_photo(user_id_to_reply, message.photo[-1].file_id, caption=reply_text, reply_markup=ticket_reply_menu_client(ticket_id))
        else:
            await bot.send_message(user_id_to_reply, f"{reply_text}\n\n{message.text}", reply_markup=ticket_reply_menu_client(ticket_id))
        
        await message.answer(f"✅ Ответ на тикет #{ticket_id} успешно отправлен.")
    except Exception as e:
        logging.error(f"Не удалось отправить ответ на тикет #{ticket_id}: {e}")
        await message.answer(f"❌ Не удалось отправить ответ. Проверьте логи для деталей.")
    
    await send_ticket_view(bot, message.chat.id, ticket_id)

@router.callback_query(AdminCallback.filter(F.action == "close_ticket"))
async def close_ticket_handler(callback: CallbackQuery, callback_data: AdminCallback, bot: Bot):
    ticket_id = callback_data.item_id
    db = SessionLocal()
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
    if not ticket or ticket.is_closed:
        await callback.answer("Тикет не найден или уже закрыт.", show_alert=True)
        db.close()
        return
        
    user_id_to_notify, is_appeal = ticket.user_id, ticket.is_appeal
    ticket.is_closed, ticket.closed_at = True, datetime.datetime.now()
    db.commit()
    db.close()
    export_tickets_to_json()
    
    await callback.answer(f"Тикет #{ticket_id} закрыт.", show_alert=True)
    try:
        text = "❌ К сожалению, ваша апелляция была отклонена." if is_appeal else "✅ Ваше обращение было закрыто."
        await bot.send_message(user_id_to_notify, text)
    except Exception as e:
        logging.warning(f"Не удалось уведомить пользователя {user_id_to_notify} о закрытии тикета: {e}")
    
    await view_single_ticket_handler(callback, callback_data)

@router.callback_query(AdminCallback.filter(F.action == "delete_ticket"))
async def delete_ticket_permanently_handler(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    ticket_id = callback_data.item_id
    db = SessionLocal()
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id, SupportTicket.is_closed == True).first()
    
    if ticket:
        is_appeal = ticket.is_appeal
        db.delete(ticket)
        db.commit()
        await callback.answer("Тикет удален навсегда.", show_alert=True)
        export_tickets_to_json()
        
        back_action = "view_appeals" if is_appeal else "view_tickets"
        back_value = "appeals" if is_appeal else "closed"
        cb_data = AdminCallback(level=2, action=back_action, value=back_value, page=0)
        await view_tickets_handler(callback, cb_data, state)
    else:
        await callback.answer("❌ Тикет не найден или не является закрытым.", show_alert=True)
    
    db.close()

# --- Секция Черного списка ---
@router.callback_query(AdminCallback.filter(F.action == "blacklist"))
async def view_blacklist_handler(callback: CallbackQuery, callback_data: AdminCallback):
    page = callback_data.page
    db = SessionLocal()
    total_items = db.query(Blacklist).count()
    total_pages = ceil(total_items / PAGE_SIZE) if total_items > 0 else 1
    users = db.query(Blacklist).order_by(Blacklist.blocked_at.desc()).limit(PAGE_SIZE).offset(page * PAGE_SIZE).all()
    db.close()
    await callback.message.edit_text(
        "🚷 Черный список пользователей:",
        reply_markup=blacklist_menu(users, page, total_pages)
    )

@router.callback_query(AdminCallback.filter(F.action == "block_user"))
async def start_block_user_handler(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    user_to_block_id = callback_data.item_id
    db = SessionLocal()
    ticket = db.query(SupportTicket).filter_by(user_id=user_to_block_id).order_by(SupportTicket.id.desc()).first()
    user_name = ticket.user_name if ticket else f"ID: {user_to_block_id}"
    db.close()
    
    await state.set_state(BlockUserState.awaiting_reason)
    await state.update_data(user_id=user_to_block_id, user_name=user_name)
    try: await callback.message.delete()
    except: pass
    await callback.message.answer(f"Введите причину блокировки для пользователя {user_name} (`{user_to_block_id}`):")
    await callback.answer()

@router.message(BlockUserState.awaiting_reason)
async def process_block_reason_handler(message: Message, state: FSMContext, bot: Bot):
    reason = message.text
    data = await state.get_data()
    user_to_block_id = data.get("user_id")
    user_name_to_block = data.get("user_name")
    await state.clear()

    db = SessionLocal()
    if db.query(Blacklist).filter_by(user_id=user_to_block_id).first():
        await message.answer("Пользователь уже в черном списке.")
        db.close()
        return

    db.add(Blacklist(user_id=user_to_block_id, user_name=user_name_to_block, reason=reason))
    
    rentals_to_revoke = db.query(Rental).filter(Rental.user_id == user_to_block_id).all()
    for rental in rentals_to_revoke:
        db.delete(rental)
    
    db.query(SupportTicket).filter(
        SupportTicket.user_id == user_to_block_id, 
        SupportTicket.is_closed == False
    ).update({"is_closed": True, "closed_at": datetime.datetime.now()}, synchronize_session=False)

    db.commit()
    db.close()
    export_blacklist_to_json()
    export_tickets_to_json()
    
    await message.answer(f"Пользователь {user_name_to_block} заблокирован по причине: '{reason}'.\nВсе его аренды аннулированы, а тикеты закрыты.")
    try:
        await bot.send_message(user_to_block_id, f"<b>Вы были заблокированы администратором.</b>\n\nПричина: {reason}\n\nВсе ваши активные аренды аннулированы. Вы можете подать апелляцию.",
                               reply_markup=appeal_keyboard())
    except Exception as e:
        logging.warning(f"Не удалось уведомить пользователя {user_to_block_id} о блокировке: {e}")
    
    await message.answer("Меню обновлено.", reply_markup=support_admin_menu())

@router.callback_query(AdminCallback.filter(F.action == "unblock_user"))
async def unblock_user_handler(callback: CallbackQuery, callback_data: AdminCallback, bot: Bot):
    user_to_unblock_id = callback_data.item_id
    db = SessionLocal()
    user = db.query(Blacklist).filter_by(user_id=user_to_unblock_id).first()
    if user:
        user_name_to_unblock = user.user_name
        db.delete(user)
        db.commit()
        export_blacklist_to_json()
        await callback.answer(f"Пользователь {user_name_to_unblock} разблокирован.", show_alert=True)
        try:
            await bot.send_message(user_to_unblock_id, "🎉 Вы были разблокированы администратором!")
        except Exception as e:
            logging.warning(f"Не удалось уведомить пользователя {user_to_unblock_id} о разблокировке: {e}")
    else:
        await callback.answer("Пользователь не найден в черном списке.", show_alert=True)
    db.close()
    
    cb_data = AdminCallback(level=1, action="blacklist", page=0)
    await view_blacklist_handler(callback, cb_data)


@router.callback_query(AdminCallback.filter(F.action == "unblock_from_appeal"))
async def unblock_from_appeal_handler(callback: CallbackQuery, callback_data: AdminCallback, bot: Bot):
    ticket_id = callback_data.item_id
    db = SessionLocal()
    
    ticket = db.query(SupportTicket).filter_by(id=ticket_id).first()
    if not ticket:
        await callback.answer("Тикет не найден!", show_alert=True)
        db.close()
        return
        
    user_to_unblock_id = ticket.user_id
    user_in_blacklist = db.query(Blacklist).filter_by(user_id=user_to_unblock_id).first()
    
    if user_in_blacklist:
        db.delete(user_in_blacklist)
    
    ticket.is_closed = True
    ticket.closed_at = datetime.datetime.now()
    db.commit()
    export_blacklist_to_json()
    export_tickets_to_json()
    
    await callback.answer(f"Пользователь {ticket.user_name} разблокирован. Апелляция закрыта.", show_alert=True)
    try:
        await bot.send_message(user_to_unblock_id, "🎉 Ваша апелляция была одобрена, и вы были разблокированы!")
    except Exception as e:
        logging.warning(f"Не удалось уведомить пользователя {user_to_unblock_id} о разблокировке: {e}")
    
    db.close()
    await callback.message.edit_text("Пользователь разблокирован. Апелляция закрыта.", reply_markup=support_admin_menu())


# --- УПРАВЛЕНИЕ КЛЮЧАМИ (ПОЛНОСТЬЮ ПЕРЕРАБОТАННЫЙ БЛОК) ---

@router.callback_query(AdminCallback.filter(F.action.in_({"view_keys", "filter_keys_all", "filter_keys_activated", "filter_keys_inactive", "activation_history"})))
async def view_keys_handler(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    await state.clear()
    page = callback_data.page
    duration_filter = callback_data.duration
    
    action = callback_data.action
    if action.startswith("filter_keys_"):
        key_filter = action.split("_")[-1]
    elif action == "activation_history":
        key_filter = "history"
    else:
        key_filter = "all"

    db=SessionLocal()
    query = db.query(ActivationKey)
    title = "🔑 Управление ключами"
    
    if key_filter == "activated" or key_filter == "history":
        query = query.filter(ActivationKey.is_activated == True).order_by(desc(ActivationKey.activated_at))
    elif key_filter == "inactive":
        query = query.filter(ActivationKey.is_activated == False)
        if duration_filter > 0:
            query = query.filter(ActivationKey.duration_days == duration_filter)
            title += f" (неакт., {duration_filter} д.)"
        else:
            title += " (все неакт.)"
        query = query.order_by(desc(ActivationKey.id))
    else: # all
        query = query.order_by(desc(ActivationKey.id))
    
    if key_filter == "history":
        title = "📜 История активаций"

    total_items = query.count()
    total_pages = ceil(total_items / PAGE_SIZE_KEYS) if total_items > 0 else 1
    keys=query.options(joinedload(ActivationKey.pool)).limit(PAGE_SIZE_KEYS).offset(page * PAGE_SIZE_KEYS).all()
    db.close()
    
    await callback.message.edit_text(title, reply_markup=keys_menu(keys, page, total_pages, key_filter, duration_filter))
    await callback.answer()

@router.callback_query(AdminCallback.filter(F.action == "select_duration_filter"))
async def select_duration_filter_handler(callback: CallbackQuery):
    db = SessionLocal()
    durations_query = db.query(ActivationKey.duration_days).filter(ActivationKey.is_activated == False).distinct().order_by(ActivationKey.duration_days).all()
    durations = [d for (d,) in durations_query]
    db.close()
    
    await callback.message.edit_text(
        "Фильтр неактивных ключей по сроку:",
        reply_markup=select_duration_filter_menu(durations)
    )
    await callback.answer()

@router.callback_query(AdminCallback.filter(F.action == "download_keys"))
async def download_filtered_keys_handler(callback: CallbackQuery, callback_data: AdminCallback):
    duration = callback_data.duration
    db = SessionLocal()
    keys_to_download = db.query(ActivationKey.key).filter(
        ActivationKey.is_activated == False, 
        ActivationKey.duration_days == duration
    ).all()
    db.close()

    if not keys_to_download:
        await callback.answer("❌ Ключи для скачивания не найдены.", show_alert=True)
        return

    keys_text = "\n".join([key for (key,) in keys_to_download])
    file_data = io.BytesIO(keys_text.encode('utf-8'))
    input_file = BufferedInputFile(file_data.getvalue(), filename=f"inactive_keys_{duration}_days.txt")
    
    await callback.message.answer_document(input_file, caption=f"📄 Ключи на {duration} дн.")
    await callback.answer()
    
@router.callback_query(AdminCallback.filter(F.action == "search_key"))
async def start_key_search_handler(callback: CallbackQuery, state: FSMContext):
    await state.set_state(SearchKeys.awaiting_query)
    await callback.message.edit_text("Введите ключ (или его часть) или ник пользователя для поиска:", reply_markup=back_button(1, "view_keys"))
    await callback.answer()

@router.message(SearchKeys.awaiting_query)
async def process_key_search_handler(message: Message, state: FSMContext):
    await state.clear()
    query_text = message.text.strip()
    
    db = SessionLocal()
    keys = db.query(ActivationKey).filter(
        or_(
            ActivationKey.key.ilike(f"%{query_text}%"),
            ActivationKey.activated_by_user_name.ilike(f"%{query_text}%")
        )
    ).order_by(desc(ActivationKey.id)).all()
    db.close()
    
    title = f"🔍 Результаты поиска по запросу «{query_text}»:"
    if not keys:
        title += "\n\n<i>Ничего не найдено.</i>"
    
    await message.answer(title, reply_markup=keys_menu(keys, 0, 1, "all"))


@router.callback_query(AdminCallback.filter(F.action == "bulk_delete_keys"))
async def start_bulk_delete_keys(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    await state.set_state(BulkDeleteKeys.selecting)
    
    key_filter = callback_data.value
    duration_filter = callback_data.duration
    
    await state.update_data(
        selected_ids=[], 
        page=0,
        key_filter=key_filter,
        duration_filter=duration_filter
    )
    
    db = SessionLocal()
    query = db.query(ActivationKey)
    title = "🗑️ Массовое удаление ключей"

    if key_filter == "activated" or key_filter == "history":
        query = query.filter(ActivationKey.is_activated == True)
        title += " (активированные)"
    elif key_filter == "inactive":
        query = query.filter(ActivationKey.is_activated == False)
        if duration_filter > 0:
            query = query.filter(ActivationKey.duration_days == duration_filter)
            title += f" (неакт., {duration_filter} д.)"
        else:
            title += " (все неакт.)"
    
    keys = query.order_by(desc(ActivationKey.id)).all()
    db.close()
    
    await state.update_data(all_key_ids=[str(k.id) for k in keys])
    
    total_pages = ceil(len(keys) / PAGE_SIZE_KEYS) if keys else 1
    
    await callback.message.edit_text(
        f"{title}\nВыберите ключи для удаления. Выбрано: 0",
        reply_markup=bulk_delete_keys_menu(keys, [], 0, total_pages, key_filter, duration_filter)
    )
    await callback.answer()

@router.callback_query(BulkDeleteKeys.selecting, AdminCallback.filter(F.action == "bulk_delete_keys_page"))
async def paginate_bulk_delete_keys(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    data = await state.get_data()
    selected_ids = data.get("selected_ids", [])
    key_filter = data.get("key_filter", "all")
    duration_filter = data.get("duration_filter", 0)
    page = callback_data.page
    await state.update_data(page=page)

    db = SessionLocal()
    query = db.query(ActivationKey)
    if key_filter == "activated" or key_filter == "history":
        query = query.filter(ActivationKey.is_activated == True)
    elif key_filter == "inactive":
        query = query.filter(ActivationKey.is_activated == False)
        if duration_filter > 0:
            query = query.filter(ActivationKey.duration_days == duration_filter)
    keys = query.order_by(desc(ActivationKey.id)).all()
    db.close()
    
    total_pages = ceil(len(keys) / PAGE_SIZE_KEYS) if keys else 1

    await callback.message.edit_text(
        f"🗑️ Выберите ключи для удаления. Выбрано: {len(selected_ids)}",
        reply_markup=bulk_delete_keys_menu(keys, selected_ids, page, total_pages, key_filter, duration_filter)
    )
    await callback.answer()

@router.callback_query(BulkDeleteKeys.selecting, AdminCallback.filter(F.action == "toggle_key_selection"))
async def toggle_key_selection(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    key_id = str(callback_data.item_id)
    data = await state.get_data()
    selected_ids = data.get("selected_ids", [])
    
    if key_id in selected_ids:
        selected_ids.remove(key_id)
    else:
        selected_ids.append(key_id)
    await state.update_data(selected_ids=selected_ids)
    
    await paginate_bulk_delete_keys(callback, state, AdminCallback(page=data.get('page', 0), action="bulk_delete_keys_page"))

@router.callback_query(BulkDeleteKeys.selecting, AdminCallback.filter(F.action.in_({"select_all_keys", "deselect_all_keys"})))
async def select_deselect_all_keys(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    data = await state.get_data()
    if callback_data.action == "select_all_keys":
        await state.update_data(selected_ids=data.get("all_key_ids", []))
    else: 
        await state.update_data(selected_ids=[])
    
    await paginate_bulk_delete_keys(callback, state, AdminCallback(page=data.get('page', 0), action="bulk_delete_keys_page"))

@router.callback_query(BulkDeleteKeys.selecting, AdminCallback.filter(F.action == "confirm_bulk_delete_keys"))
async def process_bulk_key_delete(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    selected_ids = data.get("selected_ids", [])
    if not selected_ids:
        await callback.answer("⚠️ Ключи не выбраны.", show_alert=True)
        return
        
    db = SessionLocal()
    db.query(ActivationKey).filter(ActivationKey.id.in_([int(i) for i in selected_ids])).delete(synchronize_session=False)
    db.commit()
    db.close()
    
    await callback.answer(f"✅ Удалено {len(selected_ids)} ключ(ей).", show_alert=True)
    await state.clear()
    
    cb_data = AdminCallback(level=1, action="view_keys", page=0)
    await view_keys_handler(callback, cb_data, state)

@router.callback_query(AdminCallback.filter(F.action == "add_key"))
async def add_key_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(GenerateKeys.duration)
    await callback.message.edit_text("Срок действия ключей (в днях):",reply_markup=back_button(1,"view_keys"))

@router.message(GenerateKeys.duration)
async def p_key_duration(message: Message, state: FSMContext):
    if not message.text.isdigit() or int(message.text)<=0:
        return await message.answer("❌ Введите целое положительное число.")
    await state.update_data(duration_days=int(message.text))
    await state.set_state(GenerateKeys.amount)
    await message.answer("Количество ключей для генерации (1-100):")

@router.message(GenerateKeys.amount)
async def p_key_amount(message: Message, state: FSMContext):
    if not message.text.isdigit() or not (1<=int(message.text)<=100):
        return await message.answer("❌ Введите число от 1 до 100.")
    await state.update_data(amount=int(message.text))
    db=SessionLocal()
    pools=db.query(Pool).all()
    db.close()
    if not pools:
        await message.answer("❌ Нет доступных пулов. Сначала создайте пул.")
        await state.clear()
        return
    await state.set_state(GenerateKeys.pool_id)
    await message.answer("Выберите пул, к которому будут привязаны ключи:", reply_markup=select_pool_for_key_menu(pools))

@router.callback_query(AdminCallback.filter(F.action == "p_key_pool"))
async def p_key_pool(callback: CallbackQuery, state: FSMContext, callback_data: AdminCallback):
    pool_id = callback_data.item_id
    data = await state.get_data()
    duration, amount = data['duration_days'], data['amount']
    keys_list = []
    db = SessionLocal()
    pool = db.query(Pool).filter(Pool.id == pool_id).first()
    pool_name = pool.name if pool else "N/A"
    for _ in range(amount):
        key = str(uuid.uuid4())
        db.add(ActivationKey(key=key, duration_days=duration, pool_id=pool_id))
        keys_list.append(key)
    db.commit()
    db.close()
    await state.clear()
    keys_text_for_message = "\n".join(f"<code>{k}</code>" for k in keys_list)
    await callback.message.edit_text(
        f"✅ Сгенерировано {amount} ключ(ей) для пула '{pool_name}':\n\n{keys_text_for_message}",
        reply_markup=back_button(1, "view_keys"),
        parse_mode="HTML"
    )
    keys_text_for_file = "\n".join(keys_list)
    file_data = io.BytesIO(keys_text_for_file.encode('utf-8'))
    input_file = BufferedInputFile(file_data.getvalue(), filename=f"keys_{pool_name}_{amount}шт.txt")
    await callback.message.answer_document(input_file, caption="📄 Ваши ключи в файле.")

@router.callback_query(AdminCallback.filter(F.action == "view_key"))
async def view_single_key(callback: CallbackQuery, callback_data: AdminCallback):
    db=SessionLocal(); 
    key=db.query(ActivationKey).options(joinedload(ActivationKey.pool)).filter(ActivationKey.id==callback_data.item_id).first(); 
    db.close()
    if not key: return await callback.answer("Ключ не найден!", True)
    status="✅ Активирован" if key.is_activated else "❌ Не активирован"
    text=(f"<b>Ключ:</b> <code>{key.key}</code>\n"
          f"<b>Срок:</b> {key.duration_days} дн.\n"
          f"<b>Пул:</b> {key.pool.name if key.pool else 'Неизвестно'}\n"
          f"<b>Статус:</b> {status}")
    if key.is_activated:
        text+=(f"\n\n<b>Активировал:</b>\n"
               f"<b>Имя:</b> {key.activated_by_user_name}\n"
               f"<b>ID:</b> <code>{key.activated_by_user_id}</code>\n"
               f"<b>Когда:</b> {key.activated_at.strftime('%d.%m.%Y %H:%M') if key.activated_at else ''}")
    await callback.message.edit_text(text, reply_markup=single_key_menu(key))

@router.callback_query(AdminCallback.filter(F.action == "delete_key"))
async def delete_key_handler(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    db=SessionLocal()
    key=db.query(ActivationKey).filter(ActivationKey.id==callback_data.item_id).first()
    if key and not key.is_activated: 
        db.delete(key)
        db.commit()
        await callback.answer("Ключ удален!", True)
    elif key and key.is_activated:
        await callback.answer("Этот ключ уже активирован. Его нужно отозвать.", True)
    else:
        await callback.answer("Ключ не найден.", True)
    db.close()
    cb_data = AdminCallback(level=1, action="view_keys", page=0)
    await view_keys_handler(callback, cb_data, state)

@router.callback_query(AdminCallback.filter(F.action == "revoke_key"))
async def revoke_key_handler(callback: CallbackQuery, callback_data: AdminCallback, state: FSMContext):
    db=SessionLocal()
    key=db.query(ActivationKey).filter(ActivationKey.id==callback_data.item_id).first()
    if key and key.is_activated:
        user_info = f"{key.activated_by_user_name} ({key.activated_by_user_id})"
        db.delete(key)
        db.commit()
        await callback.answer(f"Аренда для {user_info} отозвана, ключ удален!", True)
    else:
        await callback.answer("Ключ не найден или не активирован.", True)
    db.close()
    cb_data = AdminCallback(level=1, action="view_keys", page=0)
    await view_keys_handler(callback, cb_data, state)