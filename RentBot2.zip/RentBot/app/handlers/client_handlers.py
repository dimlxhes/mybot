# app/handlers/client_handlers.py
import os, datetime, logging
from sqlalchemy.orm import joinedload
from sqlalchemy import func
from aiogram import Router, F, types, Bot
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from math import ceil

from app.models.database import SessionLocal, ActivationKey, Rental, Account, Pool, SupportTicket, TicketMessage, Blacklist, AccountPoolLink, WaitingList
from app.keyboards.inline import (client_main_menu, my_rentals_menu, 
                                  single_rental_menu, back_to_client_menu, ticket_reply_menu_client, single_ticket_menu_admin, appeal_keyboard)
from app.keyboards.callbacks import ClientCallback
from app.utils import get_adobe_code, log_activation_to_json, check_and_handle_blocked_user, export_tickets_to_json, export_blacklist_to_json
from app.settings import settings_manager, get_admin_ids

router = Router()
PAGE_SIZE = 5

class Activation(StatesGroup):
    awaiting_key = State()
class SupportState(StatesGroup):
    awaiting_message = State()
    awaiting_followup = State()
class AppealState(StatesGroup):
    awaiting_appeal = State()

async def send_activation_notification(bot: Bot, data: dict):
    if not settings_manager.get("notify_on_activation"):
        return
    text = (
        f"🎉 <b>Новая активация!</b>\n\n"
        f"👤 <b>Пользователь:</b> {data['user_name']} (<code>{data['user_id']}</code>)\n"
        f"🔑 <b>Ключ:</b> <code>{data['key']}</code>\n"
        f"📦 <b>Пул:</b> {data['pool']}\n"
        f"🆔 <b>Выдан аккаунт:</b> <code>{data['account_id']}</code>\n"
        f"⏳ <b>Срок:</b> {data['duration_days']} дней"
    )
    try:
        for admin_id in get_admin_ids():
            await bot.send_message(admin_id, text)
        logging.info(f"Отправлено уведомление об активации администраторам.")
    except Exception as e:
        logging.error(f"Не удалось отправить уведомление администратору: {e}")

@router.message(CommandStart())
async def handle_start(message: Message, state: FSMContext):
    if await check_and_handle_blocked_user(message): return
    await state.clear()
    await message.answer(
        f"👋 Привет, {message.from_user.full_name}!\n\n"
        "Добро пожаловать в сервис аренды. Выберите действие:",
        reply_markup=client_main_menu()
    )

@router.callback_query(ClientCallback.filter(F.action == "main_menu"))
async def back_to_main_client_menu(callback: CallbackQuery, state: FSMContext):
    if await check_and_handle_blocked_user(callback): return
    await state.clear()
    await callback.message.edit_text(
        "Вы в главном меню. Выберите действие:",
        reply_markup=client_main_menu()
    )

@router.callback_query(ClientCallback.filter(F.action == "start_activation"))
async def start_key_activation(callback: CallbackQuery, state: FSMContext):
    if await check_and_handle_blocked_user(callback): return
    await state.set_state(Activation.awaiting_key)
    await callback.message.edit_text(
        "Пожалуйста, введите ваш ключ активации:",
        reply_markup=back_to_client_menu()
    )

# ИЗМЕНЕНА ФУНКЦИЯ: Добавлена корректная логика очереди ожидания
@router.message(Activation.awaiting_key)
async def process_key_activation(message: Message, state: FSMContext, bot: Bot):
    if await check_and_handle_blocked_user(message): return
    await state.clear()
    user_key = message.text.strip()
    db = SessionLocal()
    
    key_obj = db.query(ActivationKey).options(joinedload(ActivationKey.pool).joinedload(Pool.accounts).joinedload(AccountPoolLink.account)).filter(ActivationKey.key == user_key).first()
    
    if not key_obj:
        await message.answer("❌ Ключ не найден.", reply_markup=back_to_client_menu())
        db.close()
        return
    if key_obj.is_activated:
        await message.answer("❌ Этот ключ уже был активирован.", reply_markup=back_to_client_menu())
        db.close()
        return
    if not key_obj.pool or not key_obj.pool.accounts:
        await message.answer("❌ Ошибка конфигурации: к ключу не привязан пул с аккаунтами.", reply_markup=back_to_client_menu())
        db.close()
        return

    target_account = None
    if key_obj.pool and key_obj.pool.accounts:
        account_ids_in_pool = [link.account.id for link in key_obj.pool.accounts if link.account]
        rentals_count_query = db.query(Rental.account_id, func.count(Rental.id)).filter(
            Rental.account_id.in_(account_ids_in_pool),
            Rental.end_time > datetime.datetime.now()
        ).group_by(Rental.account_id).all()
        
        rentals_count = dict(rentals_count_query)
        for account_link in key_obj.pool.accounts:
            acc = account_link.account
            if not acc: continue
            current_rents = rentals_count.get(acc.id, 0)
            if current_rents < acc.usage_limit:
                target_account = acc
                break
    
    # Блок логики для случая, когда нет свободных аккаунтов
    if target_account is None:
        # Проверяем, не находится ли пользователь уже в очереди
        already_waiting = db.query(WaitingList).filter_by(user_id=message.from_user.id).first()
        if already_waiting:
            await message.answer("Вы уже находитесь в очереди ожидания. Пожалуйста, ожидайте.")
            db.close()
            return
            
        await message.answer("😔 К сожалению, все аккаунты из вашего пула сейчас заняты. Мы добавили вас в очередь ожидания. Администратор скоро решит ваш вопрос.")
        try:
            # Создаем новую запись в очереди
            new_waiter = WaitingList(
                user_id=message.from_user.id,
                user_name=message.from_user.full_name,
                pool_id=key_obj.pool_id,
                key_id=key_obj.id
            )
            db.add(new_waiter)
            db.commit()

            # Уведомляем админов
            for admin_id in get_admin_ids():
                await bot.send_message(admin_id, f"⚠️ Пользователь {message.from_user.full_name} (`{message.from_user.id}`) добавлен в очередь на пул `{key_obj.pool.name}`.")
        except Exception as e:
            logging.error(f"Не удалось добавить в очередь ожидания: {e}")
            db.rollback()
        finally:
            db.close()
        return
        
    # Если аккаунт найден - продолжаем активацию
    end_time = datetime.datetime.now() + datetime.timedelta(days=key_obj.duration_days)
    new_rental = Rental(user_id=message.from_user.id, account_id=target_account.id, end_time=end_time, key_id=key_obj.id)
    db.add(new_rental)
    
    key_obj.is_activated = True
    key_obj.activated_by_user_id = message.from_user.id
    key_obj.activated_by_user_name = message.from_user.full_name
    key_obj.activated_at = datetime.datetime.now()

    db.commit()
    
    activation_data = {
        "key": user_key, "activated_at": key_obj.activated_at,
        "duration_days": key_obj.duration_days, "user_id": message.from_user.id,
        "user_name": message.from_user.full_name, "pool": key_obj.pool.name if key_obj.pool else "N/A",
        "account_id": target_account.acc_id,
    }
    log_activation_to_json(activation_data)
    await send_activation_notification(bot, activation_data)
    
    db.close()

    await message.answer(
        f"✅ <b>Ключ успешно активирован!</b>\n\n"
        f"Вам выдан аккаунт: <code>{target_account.acc_id}</code>\n"
        f"Срок аренды: <b>{key_obj.duration_days} дней</b> (до {end_time.strftime('%d.%m.%Y %H:%M')}).\n\n"
        f"Просмотреть данные можно в разделе 'Мои аренды'.",
        reply_markup=client_main_menu()
    )

@router.callback_query(ClientCallback.filter(F.action == "my_rentals"))
async def view_my_rentals(callback: CallbackQuery, callback_data: ClientCallback):
    if await check_and_handle_blocked_user(callback): return
    page = callback_data.item_id 
    user_id = callback.from_user.id
    db = SessionLocal()
    query = db.query(Rental).options(joinedload(Rental.account)).filter(
        Rental.user_id == user_id,
        Rental.end_time > datetime.datetime.now()
    )
    total_rentals = query.count()
    total_pages = ceil(total_rentals / PAGE_SIZE) if total_rentals > 0 else 1
    user_rentals = query.order_by(Rental.end_time).limit(PAGE_SIZE).offset(page * PAGE_SIZE).all()
    db.close()
    if not user_rentals and page == 0:
        await callback.message.edit_text("У вас нет активных аренд.", reply_markup=back_to_client_menu())
        return
    await callback.message.edit_text(
        "📄 Ваши активные аренды:", 
        reply_markup=my_rentals_menu(user_rentals, page, total_pages)
    )

@router.callback_query(ClientCallback.filter(F.action == "view_rental"))
async def view_single_rental(callback: CallbackQuery, callback_data: ClientCallback):
    if await check_and_handle_blocked_user(callback): return
    db = SessionLocal()
    rental = db.query(Rental).options(joinedload(Rental.account)).filter(Rental.id == callback_data.item_id).first()
    if not rental or not rental.account:
        db.close()
        await callback.answer("Аренда или связанный аккаунт не найден.", show_alert=True)
        return
        
    acc_id = rental.account.acc_id
    login = rental.account.adobe_email
    password = rental.account.adobe_password
    rental_id = rental.id
    
    time_left = rental.end_time - datetime.datetime.now()
    days = time_left.days
    hours, remainder = divmod(time_left.seconds, 3600)
    minutes, _ = divmod(remainder, 60)
    
    end_time_str = rental.end_time.strftime("%d.%m.%Y в %H:%M")
    
    db.close()

    text = (
        f"✨ <b>Детали вашей аренды</b> ✨\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"🆔 <b>Аккаунт:</b> <code>{acc_id}</code>\n"
        f"👤 <b>Логин:</b> <code>{login}</code>\n"
        f"🔑 <b>Пароль:</b> <code>{password}</code>\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"⏳ <b>Активно до:</b> {end_time_str}\n"
        f"   (Осталось: {days} д. {hours} ч. {minutes} м.)"
    )

    await callback.message.edit_text(
        text=text,
        reply_markup=single_rental_menu(rental_id)
    )

@router.callback_query(ClientCallback.filter(F.action == "get_code"))
async def get_code_client(callback: CallbackQuery, callback_data: ClientCallback, bot: Bot):
    if await check_and_handle_blocked_user(callback): return
    await callback.answer("⏳ Запрашиваю код...", show_alert=False)
    db = SessionLocal()
    rental = db.query(Rental).options(joinedload(Rental.account)).filter(Rental.id == callback_data.item_id).first()
    if not rental or not rental.account:
        db.close()
        await callback.answer("Аренда или связанный аккаунт не найден.", show_alert=True)
        return
        
    imap_server = rental.account.imap_server
    imap_user = rental.account.imap_email
    imap_password = rental.account.imap_password
    acc_id_for_reply = rental.account.acc_id
    db.close()
    
    code = get_adobe_code(server=imap_server, user=imap_user, password=imap_password)
    await callback.message.answer(f"<b>Код для аккаунта <code>{acc_id_for_reply}</code></b>:\n\n<code>{code}</code>")

    if settings_manager.get("notify_on_code_request"):
        admin_notification = (
            f"ℹ️ Пользователь {callback.from_user.full_name} (`{callback.from_user.id}`) "
            f"запросил код для аккаунта `{acc_id_for_reply}`.\n\n"
            f"Код: `{code}`"
        )
        try:
            for admin_id in get_admin_ids():
                await bot.send_message(admin_id, admin_notification, parse_mode="Markdown")
        except Exception as e:
            logging.error(f"Не удалось отправить админу уведомление о запросе кода: {e}")

@router.callback_query(ClientCallback.filter(F.action == "support"))
async def start_support_ticket(callback: CallbackQuery, state: FSMContext):
    if await check_and_handle_blocked_user(callback): return
    db = SessionLocal()
    
    open_ticket = db.query(SupportTicket).filter_by(user_id=callback.from_user.id, is_closed=False).first()
    
    if open_ticket:
        db.close()
        await callback.message.edit_text(
            f"У вас уже есть открытое обращение #{open_ticket.id}.\n\n"
            "Чтобы продолжить диалог, просто отправьте следующее сообщение в этот чат или нажмите кнопку.",
            reply_markup=ticket_reply_menu_client(open_ticket.id)
        )
        await state.set_state(SupportState.awaiting_followup)
        await state.update_data(ticket_id=open_ticket.id)
        await callback.answer()
        return

    last_closed_ticket = db.query(SupportTicket).filter(
        SupportTicket.user_id == callback.from_user.id,
        SupportTicket.closed_at != None
    ).order_by(SupportTicket.closed_at.desc()).first()
    db.close()

    if last_closed_ticket:
        time_since_closure = datetime.datetime.now() - last_closed_ticket.closed_at
        if time_since_closure < datetime.timedelta(minutes=15):
            minutes_left = 15 - int(time_since_closure.total_seconds() / 60)
            await callback.answer(f"Вы сможете создать новое обращение через {minutes_left} мин.", show_alert=True)
            return

    await state.set_state(SupportState.awaiting_message)
    await callback.message.edit_text("Напишите ваше сообщение для поддержки или отправьте фото.", reply_markup=back_to_client_menu())
    await callback.answer()

@router.message(SupportState.awaiting_message, F.content_type.in_([types.ContentType.TEXT, types.ContentType.PHOTO]))
async def process_support_message(message: Message, state: FSMContext, bot: Bot):
    if await check_and_handle_blocked_user(message): return
    await state.clear()
    
    db = SessionLocal()
    new_ticket = SupportTicket(
        user_id=message.from_user.id,
        user_name=message.from_user.full_name,
    )
    db.add(new_ticket)
    db.flush() 

    new_message = TicketMessage(
        ticket_id=new_ticket.id,
        sender_type='user',
        message_text=message.text or message.caption,
        photo_file_id=message.photo[-1].file_id if message.photo else None
    )
    db.add(new_message)
    db.commit()
    ticket_id = new_ticket.id
    db.close()
    export_tickets_to_json()

    user_info = f"<b>От:</b> {message.from_user.full_name} (<code>{message.from_user.id}</code>)"
    message_content = f"<b>Сообщение:</b>\n{message.text or message.caption}" if (message.text or message.caption) else "<i>(Отправлено фото)</i>"
    text_to_admin = (
        f"🎫 <b>Новое обращение #{ticket_id}</b>\n\n"
        f"{user_info}\n\n{message_content}"
    )
    if settings_manager.get("notify_on_new_ticket"):
        try:
            for admin_id in get_admin_ids():
                if message.photo:
                    await bot.send_photo(admin_id, message.photo[-1].file_id, caption=text_to_admin, reply_markup=single_ticket_menu_admin(ticket_id, message.from_user.id, is_closed=False))
                else:
                    await bot.send_message(admin_id, text_to_admin, reply_markup=single_ticket_menu_admin(ticket_id, message.from_user.id, is_closed=False))
        except Exception as e:
            logging.error(f"Failed to send support message to admin: {e}")

    await message.answer(
        f"✅ Ваше обращение #{ticket_id} создано. Администратор скоро ответит вам.",
        reply_markup=client_main_menu()
    )

@router.callback_query(ClientCallback.filter(F.action == "reply_to_admin"))
async def start_followup_reply(callback: CallbackQuery, callback_data: ClientCallback, state: FSMContext):
    if await check_and_handle_blocked_user(callback): return
    ticket_id = callback_data.item_id
    await state.set_state(SupportState.awaiting_followup)
    await state.update_data(ticket_id=ticket_id)
    await callback.message.answer(
        f"✏️ Введите ваш ответ для тикета #{ticket_id}. Вы также можете отправить фото."
    )
    await callback.answer()

@router.message(SupportState.awaiting_followup, F.content_type.in_([types.ContentType.TEXT, types.ContentType.PHOTO]))
async def process_followup_message(message: Message, state: FSMContext, bot: Bot):
    if await check_and_handle_blocked_user(message): return
    data = await state.get_data()
    ticket_id = data.get("ticket_id")
    await state.clear()

    if not ticket_id: return

    db = SessionLocal()
    new_message = TicketMessage(
        ticket_id=ticket_id,
        sender_type='user',
        message_text=message.text or message.caption,
        photo_file_id=message.photo[-1].file_id if message.photo else None
    )
    db.add(new_message)
    db.commit()
    db.close()
    export_tickets_to_json()

    user_info = f"<b>От:</b> {message.from_user.full_name} (<code>{message.from_user.id}</code>)"
    message_content = f"<b>Сообщение:</b>\n{message.text or message.caption}" if (message.text or message.caption) else "<i>(Отправлено фото)</i>"
    text_to_admin = (
        f"💬 <b>Новый ответ в тикете #{ticket_id}</b>\n\n"
        f"{user_info}\n\n{message_content}"
    )
    if settings_manager.get("notify_on_new_ticket"):
        try:
            for admin_id in get_admin_ids():
                if message.photo:
                    await bot.send_photo(admin_id, message.photo[-1].file_id, caption=text_to_admin, reply_markup=single_ticket_menu_admin(ticket_id, message.from_user.id, is_closed=False))
                else:
                    await bot.send_message(admin_id, text_to_admin, reply_markup=single_ticket_menu_admin(ticket_id, message.from_user.id, is_closed=False))
        except Exception as e:
            logging.error(f"Failed to send followup message to admin: {e}")
            
    await message.answer("✅ Ваш ответ отправлен.")

# Логика закрытия тикета пользователем
@router.callback_query(ClientCallback.filter(F.action == "close_ticket"))
async def user_close_ticket(callback: CallbackQuery, callback_data: ClientCallback):
    if await check_and_handle_blocked_user(callback): return
    ticket_id = callback_data.item_id
    db = SessionLocal()
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
    
    if ticket and not ticket.is_closed:
        ticket.is_closed = True
        ticket.closed_at = datetime.datetime.now()
        db.commit()
        export_tickets_to_json()
        
        # ИЗМЕНЕНИЕ: Вместо удаления сообщения, просто убираем кнопки
        try:
            await callback.message.edit_text(f"{callback.message.text}\n\n--- (Обращение закрыто) ---", reply_markup=None)
        except Exception as e:
            logging.warning(f"Не удалось изменить сообщение при закрытии тикета: {e}")
        
        await callback.message.answer("✅ Обращение закрыто. Спасибо, что обратились в поддержку!")
        for admin_id in get_admin_ids():
            try:
                await callback.bot.send_message(admin_id, f"ℹ️ Пользователь закрыл тикет #{ticket_id}.")
            except Exception: pass
    elif ticket and ticket.is_closed:
        await callback.answer("Тикет уже закрыт.", show_alert=True)
    else:
        await callback.answer("Тикет не найден.", show_alert=True)
    
    db.close()
    await callback.answer()

@router.callback_query(ClientCallback.filter(F.action == "appeal"))
async def start_appeal(callback: CallbackQuery, state: FSMContext):
    db = SessionLocal()
    user_in_blacklist = db.query(Blacklist).filter(Blacklist.user_id == callback.from_user.id).first()
    if not user_in_blacklist:
        await callback.answer("Вы не в черном списке.", show_alert=True)
        db.close()
        return
    if user_in_blacklist.appeal_attempts_left <= 0:
        await callback.answer("У вас не осталось попыток апелляции.", show_alert=True)
        db.close()
        return
    if user_in_blacklist.last_appeal_at and (datetime.datetime.now() - user_in_blacklist.last_appeal_at) < datetime.timedelta(days=1):
        await callback.answer("Вы можете подавать апелляцию только раз в 24 часа.", show_alert=True)
        db.close()
        return
    await state.set_state(AppealState.awaiting_appeal)
    await callback.message.answer("Введите текст вашей апелляции. Он будет отправлен администратору на рассмотрение.")
    await callback.answer()

@router.message(AppealState.awaiting_appeal)
async def process_appeal(message: Message, state: FSMContext, bot: Bot):
    await state.clear()
    db = SessionLocal()
    user_in_blacklist = db.query(Blacklist).filter(Blacklist.user_id == message.from_user.id).first()
    if not user_in_blacklist or user_in_blacklist.appeal_attempts_left <= 0:
        db.close()
        return
    
    user_in_blacklist.appeal_attempts_left -= 1
    user_in_blacklist.last_appeal_at = datetime.datetime.now()
    
    new_ticket = SupportTicket(user_id=message.from_user.id, user_name=message.from_user.full_name, is_appeal=True)
    db.add(new_ticket)
    db.flush()

    appeal_text = f"<b>АПЕЛЛЯЦИЯ (осталось попыток: {user_in_blacklist.appeal_attempts_left})</b>\n\n{message.text}"
    new_message = TicketMessage(ticket_id=new_ticket.id, sender_type='user', message_text=appeal_text)
    db.add(new_message)
    
    db.commit()
    
    await message.answer(f"Ваша апелляция отправлена. Осталось попыток: {user_in_blacklist.appeal_attempts_left}.")
    
    admin_notification = (f"❗️❗️❗️\n<b>Новая апелляция в тикете #{new_ticket.id}</b>\n"
                          f"От: {message.from_user.full_name} (<code>{message.from_user.id}</code>)\n\n"
                          f"{message.text}")
                          
    if settings_manager.get("notify_on_new_ticket"):
        for admin_id in get_admin_ids():
            try:
                await bot.send_message(admin_id, admin_notification)
            except Exception: pass
        
    db.close()
    export_tickets_to_json()
    export_blacklist_to_json()