# app/middlewares/maintenance.py
from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from app.settings import settings_manager
from app.keyboards.callbacks import ClientCallback
import os

ADMIN_ID = int(os.getenv("ADMIN_ID"))

class MaintenanceMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any]
    ) -> Any:
        # Пропускаем администратора
        if event.from_user.id == ADMIN_ID:
            return await handler(event, data)

        # Проверяем режим тех. работ
        if settings_manager.get("maintenance_mode"):
            reason = settings_manager.get("maintenance_reason", "Ведутся технические работы.")
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="💬 Поддержка", callback_data=ClientCallback(action="support").pack())]
            ])
            
            if isinstance(event, Message):
                await event.answer(reason, reply_markup=kb)
            elif isinstance(event, CallbackQuery):
                await event.message.answer(reason, reply_markup=kb)
                await event.answer()
            return  # Не вызываем следующий обработчик

        return await handler(event, data)