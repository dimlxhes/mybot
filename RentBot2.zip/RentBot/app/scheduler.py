# app/scheduler.py
import asyncio
import datetime
import logging
# --- ИЗМЕНЕНО: Добавлен импорт Rental ---
from app.models.database import SessionLocal, ActivationKey, Rental

async def check_expired_rentals():
    """
    Асинхронная задача, которая раз в час проверяет и удаляет ключи
    с истекшим сроком аренды.
    """
    while True:
        try:
            db = SessionLocal()
            
            # --- ИСПРАВЛЕНО: Указана модель Rental для поля end_time ---
            expired_keys = db.query(ActivationKey).filter(
                ActivationKey.is_activated == True,
                ActivationKey.rental != None,
                ActivationKey.rental.has(Rental.end_time < datetime.datetime.now())
            ).all()

            if expired_keys:
                key_ids = [key.id for key in expired_keys]
                logging.info(f"Найдено {len(expired_keys)} просроченных ключей для удаления: {key_ids}")
                for key in expired_keys:
                    db.delete(key) # Каскадное удаление удалит и аренду
                db.commit()
            else:
                logging.info("Проверка просроченных аренд: не найдено.")

            db.close()
        except Exception as e:
            logging.error(f"Ошибка в задаче check_expired_rentals: {e}", exc_info=True)
            if 'db' in locals() and db.is_active:
                db.close()
        
        # Пауза на 1 час
        await asyncio.sleep(3600)