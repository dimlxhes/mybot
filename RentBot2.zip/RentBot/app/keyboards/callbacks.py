# app/keyboards/callbacks.py
from aiogram.filters.callback_data import CallbackData

class AdminCallback(CallbackData, prefix="admin"):
    level: int
    action: str
    item_id: int = 0
    page: int = 0
    value: str = "0"
    duration: int = 0 # НОВОЕ ПОЛЕ

class ClientCallback(CallbackData, prefix="client"):
    action: str
    item_id: int = 0