# app/keyboards/inline.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from .callbacks import AdminCallback, ClientCallback
from math import ceil

PAGE_SIZE = 5
PAGE_SIZE_KEYS = 10

def add_pagination_buttons(kb: InlineKeyboardMarkup, current_page: int, total_pages: int, callback_data: AdminCallback):
    if total_pages > 1:
        row = []
        if current_page > 0:
            callback_data.page = current_page - 1
            row.append(InlineKeyboardButton(text="⬅️", callback_data=callback_data.pack()))
        
        row.append(InlineKeyboardButton(text=f"📄 {current_page + 1}/{total_pages}", callback_data="dummy"))

        if current_page < total_pages - 1:
            callback_data.page = current_page + 1
            row.append(InlineKeyboardButton(text="➡️", callback_data=callback_data.pack()))
        kb.inline_keyboard.append(row)

# --- ADMIN ---

def admin_main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📒 Упр. аккаунтами", callback_data=AdminCallback(level=1, action="view_accounts").pack())],
        [InlineKeyboardButton(text="🗂️ Упр. пулами", callback_data=AdminCallback(level=1, action="view_pools").pack())],
        [InlineKeyboardButton(text="👥 Арендаторы", callback_data=AdminCallback(level=1, action="view_renters").pack())],
        [InlineKeyboardButton(text="🔑 Ключи активации", callback_data=AdminCallback(level=1, action="view_keys").pack())],
        [InlineKeyboardButton(text="⏳ Очередь ожидания", callback_data=AdminCallback(level=1, action="view_waiting_list").pack())],
        [InlineKeyboardButton(text="📊 Статус аккаунтов", callback_data=AdminCallback(level=1, action="view_status").pack())],
        [InlineKeyboardButton(text="🎫 Поддержка", callback_data=AdminCallback(level=1, action="support").pack())],
        [InlineKeyboardButton(text="🚷 Черный список", callback_data=AdminCallback(level=1, action="blacklist").pack())],
        [InlineKeyboardButton(text="⚙️ Настройки", callback_data=AdminCallback(level=1, action="settings").pack())]
    ])

def settings_menu(settings: dict, admins: list):
    maintenance_status = "✅ Включен" if settings.get('maintenance_mode') else "❌ Выключен"
    
    notifications = [
        ("notify_on_code_request", "🔔 Запрос кода"),
        ("notify_on_activation", "🎉 Активация ключа"),
        ("notify_on_new_ticket", "🎫 Новый тикет")
    ]
    
    notification_buttons = []
    for key, text in notifications:
        status = "✅" if settings.get(key) else "❌"
        notification_buttons.append(
            InlineKeyboardButton(text=f"{status} {text}", callback_data=AdminCallback(level=2, action="toggle_setting", value=key).pack())
        )
    
    admin_list_str = ", ".join(map(str, admins)) if admins else "Нет"

    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"Режим тех. работ: {maintenance_status}", callback_data=AdminCallback(level=2, action="toggle_setting", value="maintenance_mode").pack())],
        [InlineKeyboardButton(text="📝 Изменить причину тех. работ", callback_data=AdminCallback(level=2, action="edit_maintenance_reason").pack())],
        [InlineKeyboardButton(text="--- Уведомления ---", callback_data="dummy")],
        notification_buttons,
        [InlineKeyboardButton(text="--- Администраторы ---", callback_data="dummy")],
        [InlineKeyboardButton(text=f"Список: {admin_list_str}", callback_data="dummy")],
        [
            InlineKeyboardButton(text="➕ Добавить админа", callback_data=AdminCallback(level=2, action="add_admin").pack()),
            InlineKeyboardButton(text="➖ Удалить админа", callback_data=AdminCallback(level=2, action="remove_admin_list").pack())
        ],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=0, action="main_menu").pack())]
    ])

def remove_admin_menu(admins: list, main_admin_id: int):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🗑️ {admin_id}", callback_data=AdminCallback(level=3, action="remove_admin", item_id=admin_id).pack())]
        for admin_id in admins if admin_id != main_admin_id
    ])
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад в настройки", callback_data=AdminCallback(level=1, action="settings").pack())])
    return kb
    
# ИЗМЕНЕНО: Меню управления аккаунтами
def accounts_menu(accounts, current_page, total_pages):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    for acc in accounts:
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"📒 {acc.acc_id} (Лимит: {acc.usage_limit})", callback_data=AdminCallback(level=2, action="view_account", item_id=acc.id).pack())])

    pagination_cb = AdminCallback(level=1, action="view_accounts", page=current_page)
    add_pagination_buttons(kb, current_page, total_pages, pagination_cb)
    
    kb.inline_keyboard.extend([
        [
            InlineKeyboardButton(text="➕ Добавить", callback_data=AdminCallback(level=2, action="add_account").pack()),
            InlineKeyboardButton(text="📥 Загрузить", callback_data=AdminCallback(level=2, action="bulk_add").pack())
        ],
        [
            # НОВАЯ КНОПКА
            InlineKeyboardButton(text="🔄 Заменить данные", callback_data=AdminCallback(level=2, action="replace_account_start").pack())
        ],
        [
            InlineKeyboardButton(text="🗑️ Массовое удаление", callback_data=AdminCallback(level=2, action="bulk_delete_accs").pack()),
            InlineKeyboardButton(text="🔍 Проверить IMAP", callback_data=AdminCallback(level=2, action="check_imap").pack())
        ],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=0, action="main_menu").pack())]
    ])
    return kb

def bulk_delete_accounts_menu(accounts, selected_ids, page, total_pages):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    
    page_items = accounts[page*PAGE_SIZE:(page+1)*PAGE_SIZE]
    for acc in page_items:
        icon = "✅" if str(acc.id) in selected_ids else "🔲"
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"{icon} {acc.acc_id}", callback_data=AdminCallback(level=3, action="toggle_account_selection", item_id=acc.id).pack())])

    pagination_cb = AdminCallback(level=2, action="bulk_delete_accs_page", page=page)
    add_pagination_buttons(kb, page, total_pages, pagination_cb)
    
    action_row = [
        InlineKeyboardButton(text="Выбрать все", callback_data=AdminCallback(level=3, action="select_all_accs").pack()),
        InlineKeyboardButton(text="Снять все", callback_data=AdminCallback(level=3, action="deselect_all_accs").pack())
    ]
    kb.inline_keyboard.append(action_row)
    if selected_ids:
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"🗑️ Удалить выбранные ({len(selected_ids)})", callback_data=AdminCallback(level=3, action="confirm_bulk_delete_accs").pack())])
    
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=1, action="view_accounts").pack())])
    return kb

def single_account_menu(account_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📝 Логин", callback_data=AdminCallback(level=3, action="edit_login", item_id=account_id).pack()),
            InlineKeyboardButton(text="🔑 Пароль", callback_data=AdminCallback(level=3, action="edit_password", item_id=account_id).pack())
        ],
        [
            InlineKeyboardButton(text="✉️ Email", callback_data=AdminCallback(level=3, action="edit_adobe_email", item_id=account_id).pack()),
            InlineKeyboardButton(text="🔑 Пароль Email", callback_data=AdminCallback(level=3, action="edit_imap_password", item_id=account_id).pack())
        ],
        [
            InlineKeyboardButton(text="🌐 IMAP", callback_data=AdminCallback(level=3, action="edit_imap_server", item_id=account_id).pack()),
            InlineKeyboardButton(text="👥 Лимит", callback_data=AdminCallback(level=3, action="set_limit", item_id=account_id).pack())
        ],
        [InlineKeyboardButton(text="🔑 Получить код", callback_data=AdminCallback(level=3, action="get_code", item_id=account_id).pack())],
        [InlineKeyboardButton(text="🗑️ Удалить аккаунт", callback_data=AdminCallback(level=3, action="delete_account", item_id=account_id).pack())],
        [InlineKeyboardButton(text="⬅️ Назад к списку", callback_data=AdminCallback(level=1, action="view_accounts").pack())]
    ])

# ИЗМЕНЕНО: Меню арендаторов
def renters_menu(rentals, current_page, total_pages, pool_id=None):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🗂️ Фильтр по пулу", callback_data=AdminCallback(level=2, action="select_pool_for_filter").pack())]
    ])
    if pool_id:
        kb.inline_keyboard.append([InlineKeyboardButton(text="🔄 Сбросить фильтр", callback_data=AdminCallback(level=1, action="view_renters").pack())])

    for rental in rentals:
        if rental.account and rental.key:
            end_time_str = rental.end_time.strftime("%d.%m.%Y")
            user_name = rental.key.activated_by_user_name or "N/A"
            rental_info = f"👤 {user_name} ({rental.account.acc_id}) до {end_time_str}"
            kb.inline_keyboard.append([InlineKeyboardButton(text=rental_info, callback_data=AdminCallback(level=3, action="view_renter_details", item_id=rental.id).pack())])
            
            # Ряд кнопок для каждого арендатора
            action_row = [
                InlineKeyboardButton(text="🔄 Заменить", callback_data=AdminCallback(level=2, action="start_replacement", item_id=rental.id).pack()),
                InlineKeyboardButton(text="🗑️ Отозвать", callback_data=AdminCallback(level=2, action="revoke_rental", item_id=rental.id).pack()),
                # НОВАЯ КНОПКА
                InlineKeyboardButton(text="💬 Написать", callback_data=AdminCallback(level=2, action="dm_renter_single", item_id=rental.user_id).pack())
            ]
            kb.inline_keyboard.append(action_row)
            
    pagination_cb = AdminCallback(level=1, action="view_renters", item_id=pool_id if pool_id else 0, page=current_page)
    add_pagination_buttons(kb, current_page, total_pages, pagination_cb)
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=0, action="main_menu").pack())])
    return kb

def select_pool_for_filter_menu(pools):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🗂️ {pool.name}", callback_data=AdminCallback(level=1, action="view_renters", item_id=pool.id).pack())]
        for pool in pools
    ])
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад к арендаторам", callback_data=AdminCallback(level=1, action="view_renters").pack())])
    return kb

def select_account_for_replacement_menu(accounts, back_callback_data):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"✅ {acc.acc_id}", callback_data=AdminCallback(level=3, action="select_replacement_acc", item_id=acc.id).pack())]
        for acc in accounts
    ])
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Отмена", callback_data=back_callback_data)])
    return kb

def list_accounts_for_removal_menu(pool, back_callback_data):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🗑️ {link.account.acc_id}", callback_data=AdminCallback(level=3, action="remove_acc_from_pool", item_id=link.id).pack())]
        for link in pool.accounts if link.account
    ])
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад к пулу", callback_data=back_callback_data)])
    return kb

def support_admin_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📬 Открытые тикеты", callback_data=AdminCallback(level=2, action="view_tickets", value="open").pack())],
        [InlineKeyboardButton(text="🗃️ Закрытые тикеты", callback_data=AdminCallback(level=2, action="view_tickets", value="closed").pack())],
        [InlineKeyboardButton(text="🗑️ Массовое удаление тикетов", callback_data=AdminCallback(level=2, action="bulk_delete_tickets").pack())],
        [InlineKeyboardButton(text="📜 Апелляции", callback_data=AdminCallback(level=2, action="view_appeals").pack())],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=0, action="main_menu").pack())]
    ])

def bulk_delete_tickets_menu(tickets, selected_ids, page, total_pages):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    
    page_items = tickets[page*PAGE_SIZE:(page+1)*PAGE_SIZE]
    for ticket in page_items:
        icon = "✅" if str(ticket.id) in selected_ids else "🔲"
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"{icon} #{ticket.id} от {ticket.user_name}", callback_data=AdminCallback(level=3, action="toggle_ticket_selection", item_id=ticket.id).pack())])

    pagination_cb = AdminCallback(level=2, action="bulk_delete_tickets_page", page=page)
    add_pagination_buttons(kb, page, total_pages, pagination_cb)
    
    action_row = [
        InlineKeyboardButton(text="Выбрать все", callback_data=AdminCallback(level=3, action="select_all_tickets").pack()),
        InlineKeyboardButton(text="Снять все", callback_data=AdminCallback(level=3, action="deselect_all_tickets").pack())
    ]
    kb.inline_keyboard.append(action_row)
    if selected_ids:
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"🗑️ Удалить выбранные ({len(selected_ids)})", callback_data=AdminCallback(level=3, action="confirm_bulk_delete_tickets").pack())])
    
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=1, action="support").pack())])
    return kb

def view_tickets_menu(tickets, current_page, total_pages, ticket_filter):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    for ticket in tickets:
        ticket_text_preview = "[Фото]"
        if ticket.messages and ticket.messages[0].message_text:
            ticket_text_preview = ticket.messages[0].message_text[:30]
        
        appeal_tag = "❗️" if ticket.is_appeal else ""
        kb.inline_keyboard.append([InlineKeyboardButton(
            text=f"{appeal_tag}#{ticket.id} от {ticket.user_name} - «{ticket_text_preview}...»",
            callback_data=AdminCallback(level=3, action="view_ticket", item_id=ticket.id).pack()
        )])
    
    pagination_cb = AdminCallback(level=2, action="view_tickets", value=ticket_filter, page=current_page)
    add_pagination_buttons(kb, current_page, total_pages, pagination_cb)
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=1, action="support").pack())])
    return kb

def single_ticket_menu_admin(ticket_id, user_id, is_closed, is_appeal=False):
    kb = []
    if is_appeal and not is_closed:
        kb.append([InlineKeyboardButton(text="✅ Разбанить и закрыть", callback_data=AdminCallback(level=4, action="unblock_from_appeal", item_id=ticket_id).pack())])

    if not is_closed:
        action_buttons = [
            InlineKeyboardButton(text="💬 Ответить", callback_data=AdminCallback(level=4, action="reply_to_ticket", item_id=ticket_id).pack()),
            InlineKeyboardButton(text="❌ Закрыть (отклонить)", callback_data=AdminCallback(level=4, action="close_ticket", item_id=ticket_id).pack())
        ]
        kb.append(action_buttons)
        if not is_appeal:
            kb.append([InlineKeyboardButton(text="🚫 Заблокировать", callback_data=AdminCallback(level=4, action="block_user", item_id=user_id).pack())])
    else:
        kb.append([InlineKeyboardButton(text="🗑️ Удалить тикет", callback_data=AdminCallback(level=4, action="delete_ticket", item_id=ticket_id).pack())])

    back_action = "view_appeals" if is_appeal else "view_tickets"
    back_value = "appeals" if is_appeal else ("closed" if is_closed else "open")
    kb.append([InlineKeyboardButton(text="⬅️ К списку", callback_data=AdminCallback(level=2, action=back_action, value=back_value).pack())])
    return InlineKeyboardMarkup(inline_keyboard=kb)


def blacklist_menu(users, current_page, total_pages):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    for user in users:
        kb.inline_keyboard.append([
            InlineKeyboardButton(
                text=f"👤 {user.user_name} ({user.user_id})",
                callback_data="dummy"
            ), 
            InlineKeyboardButton(
                text="✅ Разблокировать",
                callback_data=AdminCallback(level=2, action="unblock_user", item_id=user.user_id).pack()
            )
        ])
    pagination_cb = AdminCallback(level=1, action="blacklist", page=current_page)
    add_pagination_buttons(kb, current_page, total_pages, pagination_cb)
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=0, action="main_menu").pack())])
    return kb


def pools_menu(pools, current_page, total_pages):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        *[[InlineKeyboardButton(text=f"🗂️ {p.name} ({len(p.accounts)})", callback_data=AdminCallback(level=2, action="view_pool", item_id=p.id).pack())] for p in pools],
    ])
    pagination_cb = AdminCallback(level=1, action="view_pools", page=current_page)
    add_pagination_buttons(kb, current_page, total_pages, pagination_cb)
    kb.inline_keyboard.extend([
        [InlineKeyboardButton(text="➕ Создать пул", callback_data=AdminCallback(level=2, action="add_pool").pack())],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=0, action="main_menu").pack())]
    ])
    return kb
    
def single_pool_menu(pool):
    kb = [[InlineKeyboardButton(text="➕ Добавить аккаунт", callback_data=AdminCallback(level=3, action="add_acc_to_pool", item_id=pool.id).pack())]]
    if pool.accounts:
         kb.append([InlineKeyboardButton(text="➖ Убрать аккаунт", callback_data=AdminCallback(level=3, action="list_acc_for_removal", item_id=pool.id).pack())])
    kb.append([InlineKeyboardButton(text="❌ Удалить пул", callback_data=AdminCallback(level=3, action="delete_pool", item_id=pool.id).pack())])
    kb.append([InlineKeyboardButton(text="⬅️ Назад к пулам", callback_data=AdminCallback(level=1, action="view_pools").pack())])
    return InlineKeyboardMarkup(inline_keyboard=kb)

def select_duration_filter_menu(durations: list[int]):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    kb.inline_keyboard.append([InlineKeyboardButton(text="Показать все неактивные", callback_data=AdminCallback(level=1, action="filter_keys_inactive", duration=0).pack())])
    
    for duration in sorted(durations):
        kb.inline_keyboard.append(
            [
                InlineKeyboardButton(
                    text=f"{duration} дн.", 
                    callback_data=AdminCallback(level=1, action="filter_keys_inactive", duration=duration).pack()
                ),
                InlineKeyboardButton(
                    text="📥 Скачать", 
                    callback_data=AdminCallback(level=2, action="download_keys", duration=duration).pack()
                )
            ]
        )

    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=1, action="view_keys").pack())])
    return kb

def keys_menu(keys, current_page, total_pages, current_filter, duration_filter=0):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    filter_actions = {"all": "Все", "activated": "✅ Акт.", "inactive": "❌ Неакт."}
    
    filter_buttons = []
    for action, text in filter_actions.items():
        if action == current_filter:
            text = f"▶️ {text} ◀️"
        
        cb_action = "select_duration_filter" if action == "inactive" else f"filter_keys_{action}"
        filter_buttons.append(InlineKeyboardButton(text=text, callback_data=AdminCallback(level=1, action=cb_action).pack()))
    
    kb.inline_keyboard.append(filter_buttons)
    kb.inline_keyboard.append([
        InlineKeyboardButton(text="🔍 Поиск", callback_data=AdminCallback(level=2, action="search_key").pack()),
        InlineKeyboardButton(text="📜 История активаций", callback_data=AdminCallback(level=2, action="activation_history").pack())
    ])

    for key in keys:
        status = "✅" if key.is_activated else "❌"
        user_name = f"({key.activated_by_user_name})" if key.activated_by_user_name else ""
        key_text = f"{status} {key.key[:8]}... ({key.duration_days} д.) {user_name}"
        kb.inline_keyboard.append([InlineKeyboardButton(text=key_text, callback_data=AdminCallback(level=2, action="view_key", item_id=key.id).pack())])
    
    pagination_cb = AdminCallback(level=1, action=f"filter_keys_{current_filter}", page=current_page, duration=duration_filter)
    add_pagination_buttons(kb, current_page, total_pages, pagination_cb)
    
    kb.inline_keyboard.extend([
        [InlineKeyboardButton(text="➕ Сгенерировать", callback_data=AdminCallback(level=2, action="add_key").pack())],
        [InlineKeyboardButton(text="🗑️ Массовое удаление", callback_data=AdminCallback(level=2, action="bulk_delete_keys", value=current_filter, duration=duration_filter).pack())],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=0, action="main_menu").pack())]
    ])
    return kb

def bulk_delete_keys_menu(keys, selected_ids, current_page, total_pages, current_filter, duration_filter=0):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    page_keys = keys[current_page*PAGE_SIZE_KEYS:(current_page+1)*PAGE_SIZE_KEYS]

    for key in page_keys:
        icon = "✅" if str(key.id) in selected_ids else "🔲"
        status = " (акт.)" if key.is_activated else f" ({key.duration_days} д.)"
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"{icon} {key.key[:12]}...{status}", callback_data=AdminCallback(level=3, action="toggle_key_selection", item_id=key.id).pack())])

    pagination_cb = AdminCallback(level=2, action="bulk_delete_keys", page=current_page, value=current_filter, duration=duration_filter)
    add_pagination_buttons(kb, current_page, total_pages, pagination_cb)
    
    action_row = [
        InlineKeyboardButton(text="Выбрать все", callback_data=AdminCallback(level=3, action="select_all_keys").pack()),
        InlineKeyboardButton(text="Снять все", callback_data=AdminCallback(level=3, action="deselect_all_keys").pack())
    ]
    kb.inline_keyboard.append(action_row)
    if selected_ids:
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"🗑️ Удалить выбранные ({len(selected_ids)})", callback_data=AdminCallback(level=3, action="confirm_bulk_delete_keys").pack())])
    
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=1, action=f"filter_keys_{current_filter}", duration=duration_filter).pack())])
    return kb

def single_key_menu(key_obj):
    kb = []
    if key_obj.is_activated:
        kb.append([InlineKeyboardButton(text="🗑️ Отозвать и удалить", callback_data=AdminCallback(level=3, action="revoke_key", item_id=key_obj.id).pack())])
    else:
        kb.append([InlineKeyboardButton(text="🗑️ Удалить ключ", callback_data=AdminCallback(level=3, action="delete_key", item_id=key_obj.id).pack())])
    kb.append([InlineKeyboardButton(text="⬅️ Назад к ключам", callback_data=AdminCallback(level=1, action="view_keys").pack())])
    return InlineKeyboardMarkup(inline_keyboard=kb)

def select_pool_for_key_menu(pools):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=f"🗂️ {p.name}", callback_data=AdminCallback(level=3, action="p_key_pool", item_id=p.id).pack())] for p in pools])

def back_button(level, action, item_id=0, value="0"):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=level, action=action, item_id=item_id, value=value).pack())]])

# НОВЫЕ ФУНКЦИИ: Меню для очереди ожидания
def waiting_list_menu(waiting_users, current_page, total_pages):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    if not waiting_users and current_page == 0:
        kb.inline_keyboard.append([InlineKeyboardButton(text="Очередь пуста", callback_data="dummy")])
    
    for wait in waiting_users:
        text = f"👤 {wait.user_name} (Пул: {wait.pool.name if wait.pool else 'N/A'})"
        kb.inline_keyboard.append([InlineKeyboardButton(text=text, callback_data=AdminCallback(level=2, action="view_waiter", item_id=wait.id).pack())])

    pagination_cb = AdminCallback(level=1, action="view_waiting_list", page=current_page)
    add_pagination_buttons(kb, current_page, total_pages, pagination_cb)
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=AdminCallback(level=0, action="main_menu").pack())])
    return kb
    
def single_waiter_menu(waiter_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Активировать аренду", callback_data=AdminCallback(level=3, action="manual_assign", item_id=waiter_id).pack())],
        [InlineKeyboardButton(text="🗑️ Удалить из очереди", callback_data=AdminCallback(level=3, action="remove_from_waitlist", item_id=waiter_id).pack())],
        [InlineKeyboardButton(text="⬅️ К очереди", callback_data=AdminCallback(level=1, action="view_waiting_list").pack())]
    ])

# --- CLIENT ---

def client_main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔑 Активировать ключ", callback_data=ClientCallback(action="start_activation").pack())],
        [InlineKeyboardButton(text="📄 Мои аренды", callback_data=ClientCallback(action="my_rentals").pack())],
        [InlineKeyboardButton(text="💬 Поддержка", callback_data=ClientCallback(action="support").pack())]
    ])

def my_rentals_menu(rentals, current_page, total_pages):
    kb = InlineKeyboardMarkup(inline_keyboard=[])
    for rental in rentals:
        if rental.account:
            end_time = rental.end_time.strftime("%d.%m.%Y")
            kb.inline_keyboard.append([InlineKeyboardButton(text=f"Аккаунт: {rental.account.acc_id} (до {end_time})", callback_data=ClientCallback(action="view_rental", item_id=rental.id).pack())])
    
    page_row = []
    if current_page > 0:
        page_row.append(InlineKeyboardButton(text="⬅️", callback_data=ClientCallback(action="my_rentals", item_id=current_page-1).pack()))
    if total_pages > 0:
        page_row.append(InlineKeyboardButton(text=f"{current_page + 1}/{total_pages}", callback_data="dummy"))
    if current_page < total_pages - 1:
        page_row.append(InlineKeyboardButton(text="➡️", callback_data=ClientCallback(action="my_rentals", item_id=current_page+1).pack()))
    if page_row:
        kb.inline_keyboard.append(page_row)
    
    kb.inline_keyboard.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=ClientCallback(action="main_menu").pack())])
    return kb

def single_rental_menu(rental_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔑 Получить код", callback_data=ClientCallback(action="get_code", item_id=rental_id).pack())],
        [InlineKeyboardButton(text="⬅️ Назад к арендам", callback_data=ClientCallback(action="my_rentals").pack())]
    ])

def back_to_client_menu():
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Назад", callback_data=ClientCallback(action="main_menu").pack())]])

def ticket_reply_menu_client(ticket_id):
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="💬 Ответить", callback_data=ClientCallback(action="reply_to_admin", item_id=ticket_id).pack()),
        InlineKeyboardButton(text="✅ Закрыть тикет", callback_data=ClientCallback(action="close_ticket", item_id=ticket_id).pack())
    ]])

def appeal_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Подать апелляцию", callback_data=ClientCallback(action="appeal").pack())]
    ])